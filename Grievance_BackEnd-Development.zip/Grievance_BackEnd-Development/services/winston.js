var appRoot = require('app-root-path');
var winston = require("winston");
require("winston-mongodb");

const myformat = winston.format.combine(
	winston.format.colorize(),
	winston.format.timestamp(),
	winston.format.printf(info =>`${info.timestamp} ${info.level}: ${info.message}`)
);
const options = {
	file: {
		level: "info",
		filename: `${appRoot}/logs/app.log`,
		handleExceptions: true,
		json: true,
		maxsize: 5242880, // 5MB
		maxFiles: 5,
		colorize: true,
	},
	console: {
		level: "debug",
		handleExceptions: true,
		json: false,
		colorize: true,
		format:myformat
	},
	database: {
		level: "error",
		db: process.env.mongoDB_URL,
		collection: "error-logs",
		options: { useUnifiedTopology: true },
		format: winston.format.combine(
			winston.format.timestamp(),
			winston.format.json()
		),
	},
};
var logger = winston.createLogger({
	transports: [
		new winston.transports.File(options.file),
		new winston.transports.Console(options.console),
		new winston.transports.MongoDB(options.database),
	],
	exceptionHandlers: [
		new winston.transports.File({
			filename: `${appRoot}/logs/exceptions.log`,
			timestamp: true,
			maxsize: 1000000,
		}),
		new winston.transports.MongoDB(options.database),
	],
	exitOnError: false, // do not exit on handled exceptions
});

logger.stream = {
	write: function (message,req) {
		const status = message.split(" ")[8]
		const logs = (status === '404' || status === '500') ? logger.error(message) : status === '200' ? logger.info(message) : logger.warn(message);
		return logs;
	},
};
  
module.exports = logger;