const express = require('express');
const app = express();
const env = require('dotenv');
var cors = require('cors')
env.config();
const bodyParser = require('body-parser');
const path = require("path");
const morgan = require('morgan');
const winston = require('./services/winston');
const routes = require('./src/routes/index');
// const userRoutes = require('./src/users/users.routes');
// const officerRoutes = require('./src/officer/officer.routes');
// const complaintRoutes = require('./src/complaint/complaint.routes');
// const masterDataRoutes = require('./src/masterData/masterData.routes');


const ContentSecurityPolicy = `
    default-src 'self' 'unsafe-inline' https://117.254.87.83:4000 https://117.254.87.83:3000;
    script-src 'self' 'unsafe-inline';
    child-src https://117.254.87.83:4000 https://117.254.87.83:3000;
    style-src 'self' 'unsafe-inline' https://117.254.87.83:4000 https://117.254.87.83:3000 https://fonts.googleapis.com https://www.gstatic.com;
    font-src 'self' 'unsafe-inline' https://fonts.gstatic.com;
    img-src * 'self' data: https:;
  `
/*
const allowedOrigins = ['http://127.0.0.1:3000', 'http://localhost:3000','https://127.0.0.1:3000', 
    'https://localhost:3000', 'https://127.0.0.1:4000', 'https://localhost:4000',
    'http://117.254.87.83:3000','https://117.254.87.83:3000','http://117.254.87.83:3002',
    'https://117.254.87.83:3002', 'https://117.254.87.83:4000',
    'http://152.70.142.148', 'https://152.70.142.148', 'http://129.153.120.149',
    'https://129.153.120.149', 'http://127.0.0.1:4000', 'http://localhost:4000',
    'https://117.254.87.83:8091'];
    

app.use(cors({
    origin: allowedOrigins
}));
*/

app.disable('x-powered-by');

app.use((req, res, next) => {
    const origin = req.headers.origin;
//    if (allowedOrigins.includes(origin) ) {
       res.setHeader('Access-Control-Allow-Origin', '*');
  //  }
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE');
    res.header('Access-Control-Expose-Headers', 'Content-Length');
    res.header('X-XSS-Protection', '1; mode=block');
    res.header('X-Content-Type-Options', 'nosniff');
    res.header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    res.header('Content-Security-Policy', ContentSecurityPolicy.replace(/\s{2,}/g, ' ').trim());
    res.header('Access-Control-Allow-Headers', 'Accept, Authorization, Content-Type, X-Requested-With, Range');
    res.removeHeader("X-Powered-By");
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    } else {
        return next();
    }
});

app.use(morgan('combined', { stream: winston.stream }));

app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 50000 }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/images", express.static(path.join(__dirname, "images")));
app.use("/assets", express.static(path.join(__dirname, "assets")));

app.use("/grievanceService", routes);

// userRoutes.routesConfig(app);
// officerRoutes.routesConfig(app);
// complaintRoutes.routesConfig(app);
// masterDataRoutes.routesConfig(app);

// Capture 500 erors
app.use((err,req,res,next) => {
        res.status(500).send(err);
        winston.error(`${err.status || 500} - ${res.statusMessage} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`,);
})

// Capture 404 erors
app.use((err,req,res,next) => {
        res.status(404).send(err);
        winston.info(`400 || ${res.statusMessage} - ${req.originalUrl} - ${req.method} - ${req.ip}`)
})

app.listen(process.env.PORT, () => { 
    console.log('Server is listening at ' + process.env.IP_ADDRESS +':%s', process.env.PORT); 
});