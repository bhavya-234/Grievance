const handler = require('./masterData.handler');
const jwt = require('../services/auth.service');
const express = require('express');
const router = express.Router();
/*
exports.routesConfig = (app) => {
    // app.post('/api/v1/masterdata', [handler.masterData]);
    // app.get('/api/categories', [handler.getCategories]);
    app.post('/masterdata', [handler.masterData]);
    app.get('/categories', [handler.getCategories]);

}
*/
router.post('/masterdata', [handler.masterData]);
router.get('/categories', [handler.getCategories]);

module.exports = router;