const userModel = require('./model/masterData.model');
const officerModel = require('../officer/model/officer.model');
const jwt = require('../services/auth.service');
const fs = require("fs");
const path = require("path");

exports.masterData = (req) => {
    try {
        let filepath = path.join(__dirname, "./state_data.json");
        const jsonString = fs.readFileSync(filepath);
        const customer = JSON.parse(jsonString);
        return new Promise((resolve, reject) => {
            userModel.create(customer)
                .then(response => {
                    resolve("Data added");
                }).catch(err => reject(err));
        });
    } catch (err) {
        console.log("process error" , err.message);
    }
};

exports.getCategories = (req) => {
    let conditionObj = {};
    let requiredKeysObj = { _id: 0 };
    let reqKey;
    let sortCon = {};
        
    return new Promise((resolve, reject) => {
        try{
            if (req.query.sroName) {
                officerModel.find({ sro: req.query.sroName, role: "DR" })
                .then(response => {
                    if (response.length > 0) {
                        resolve([response[0].loginName]);
                    } else {
                        resolve([]);
                    }
                })
                .catch(err => reject(err));
            }
            else
            {
                console.log(req.query);
                let validationResponse = validateCategoriesRequest(req.query);
                if(!validationResponse){
                    return reject("Invalidate Input")
                }

                if (req.query.state && req.query.district && req.query.mandal) {
                    conditionObj = {
                        districtName: req.query.district,
                        mandalName: req.query.mandal,
                        sroName:{$ne:null}
                    }
                    //requiredKeysObj.villageName=1;
                    requiredKeysObj.sroName = 1;
                    reqKey = "sroName"
                    sortCon = { "sroName": 'asc' }
                } else if (req.query.state && req.query.district) {
                    conditionObj = {
                        districtName: req.query.district
                    }
                    requiredKeysObj.mandalName = 1;
                    reqKey = "mandalName"
                    sortCon = { "mandalName": 'asc' }
                } else {
                    requiredKeysObj.districtName = 1;
                    reqKey = "districtName"
                    sortCon = { "districtName": 'asc' }
                }
        
                userModel.find(conditionObj, requiredKeysObj).sort(sortCon)
                .then(response => {
                    if (response) {
                        const unique = [...new Set(response.map(item => item[reqKey]))]
                        resolve(unique);
                    } else {
                        reject("feaching failed")
                    }

                })
                .catch(err => reject(err));
            }  
        } catch (err) {
            console.log("process error" , err.message);
            reject(err)
        } 
    })
    
};


validateCategoriesRequest= (params) => {
    const {state, district, mandal} = params;
    
    if(state != null && ! (state.constructor == String && state.length > 0) )
        return false;
    if(district != null && ! (district.constructor == String && district.length > 0) )
        return false;
    if(mandal != null && ! (mandal.constructor == String && mandal.length > 0) )
        return false;
    return true;
}
