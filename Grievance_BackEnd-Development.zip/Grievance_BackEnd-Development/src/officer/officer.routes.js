const handler = require('./officer.handler');
const jwt = require('../services/auth.service');
const officer = require('./officer.controller')

const express = require('express');
const router = express.Router();

// exports.routesConfig = (app) => {
//     // app.post('/api/officer/signup', [handler.signUp]);
//     // app.post('/api/officer/login', [handler.login]);
//     // app.get('/api/officer/logout', jwt.tokenInvalidate, [handler.logout]);
//     // app.post('/api/officer/resetPassword',jwt.verifyOfficerJwt, [handler.reset]);
// 	// //app.put('/api/officer/resetPassword',[handler.reset])
// }

router.post('/signup', [handler.signUp]);
router.post('/login', [handler.login]);
router.get('/login/getPassword/:loginEmail', [handler.getLoginPassword]);
router.get('/logout', jwt.tokenInvalidate, [handler.logout]);
router.post('/resetPassword',jwt.verifyOfficerJwt, [handler.reset]);
router.get('/randomPassword', [handler.randomPasswordGenerator]);

module.exports = router;