const service = require('./officer.controller');
const { Handler,reqHandler } = require('../common/requestHandler');

//FORMAT:  exports.<action>=(req,res)=>Handler(req,res,service.<function>,<successMessage>,<failMessage>);
exports.login = (req, res) => Handler(req, res, service.login, 'Success', 'User Details access failed');
exports.getLoginPassword = (req, res) => Handler(req, res, service.getLoginPassword, 'Success', 'User Details access failed');
exports.signUp = (req, res) => { Handler(req, res, service.signUp, 'Success', 'Save Failed'); }
exports.logout = (req, res) => { Handler(req, res, service.logout, 'Success', 'Logout Failed'); }
exports.reset =async (req,res)=> { Handler(req, res, service.resetPassword, 'Success', 'Password Reset Failed'); }
exports.randomPasswordGenerator =async (req,res)=> { Handler(req, res, service.randomPasswordGenerator, 'Success', 'Password Reset Failed'); }
