const mongoose = require("../../services/mongoose.service").mongoose;
const Schema = mongoose.Schema;

const officerSchema = new Schema({
    // appNo: { type: String , default: Date.now(), unique : true},
    loginType:{type:String, default:"officer"},
    loginKey: { type: String },
    loginName: { type: String },
    loginEmail: { type: String },
    loginMobile: { type: String },
    loginPassword: { type: String },
	sroDistrict:{type:String},
	sroMandal:{type:String},
	sroOffice:{type:String},
	sroNumber:{type:String},
    role: {type:String},
    district: {type:String},
    subDistrict: {type:Array},
    sro: {type:String},
    lastLogin:{type:String},
    currentLogin:{type:String},
    loginStatus:{ type: String ,default: "" },
    loginAttemptsLeft: { type: Number, default: 5 },
    loginBlockedUntil: { type: Date, default: null },
},{timestamps:true});

module.exports = mongoose.model("officers", officerSchema, "officers");
