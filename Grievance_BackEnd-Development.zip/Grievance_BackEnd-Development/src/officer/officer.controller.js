const userModel = require('./model/officer.model');
const jwt = require('../services/auth.service');
const bcrypt = require('bcryptjs');
const saltRounds = 10;
const moment = require('moment');
var CryptoJS = require("crypto-js");
var xl = require('excel4node');
const RandExp = require('randexp');

const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[a-zA-Z\d@$!%*#?&]{8,}$/;
const secretKey = "Grievance_Secret_Key"

exports.signUp = (req) => {
    
        return new Promise((resolve, reject) => {
            try {
                let reqObj = req.body;
            userModel.find({ loginEmail: reqObj.loginEmail })
                .then(async response => {
                    if (response.length > 0) {
                        reject("Mail id already exists ")
                    } else {
                        const myPlaintextPassword = reqObj.loginPassword;
                        reqObj.loginPassword = await bcrypt.hash(myPlaintextPassword, saltRounds)
                        userModel.create(reqObj)
                            .then(response => {
                                resolve(response instanceof userModel);
                            }).catch(err => reject(err));
                    }

                })
                .catch(err => reject(err));
            } catch (err) {
                console.log("process error" , err);
                reject(err);
            }
        });
   
};

const updateUserLoginTrials = async (findOfficerQuery, loginAttemptsLeft, loginBlockedUntil) => {
	await userModel.findOneAndUpdate(findOfficerQuery,
	{ $set: { loginAttemptsLeft: loginAttemptsLeft, loginBlockedUntil: loginBlockedUntil } }, { upsert: false, multi:false }
	);
}

exports.login = (req) => {
  
        return new Promise((resolve, reject) => {
            try {
            userModel.findOne({ loginEmail: { $regex: new RegExp(`^${req.body.loginEmail}$`), $options: 'i' } },
                { _id: 1, loginPassword: 1, loginEmail: 1, loginName: 1, loginType: 1, sroDistrict: 1, sroMandal: 1, sroOffice: 1, sroNumber: 1, role: 1,sro:1, district: 1, loginAttemptsLeft: 1, loginBlockedUntil: 1, lastLogin: 1, currentLogin: 1})
                .then(async response => {
                    if (response) {
                    
                        const findOfficerQuery = { "loginEmail": req.body.loginEmail };
                        var date = new Date();
                        var dateStr =
                        ("00" + date.getDate()).slice(-2) + "-" +
                        ("00" + (date.getMonth() + 1)).slice(-2) + "-" +
                        date.getFullYear() + " " +
                        ("00" + date.getHours()).slice(-2) + ":" +
                        ("00" + date.getMinutes()).slice(-2) + ":" +
                        ("00" + date.getSeconds()).slice(-2);
                        let lastLoginUpdate = {
                            lastLogin: response.currentLogin,
                            currentLogin: dateStr
                        };

                        if (response.loginAttemptsLeft === 0) {
                            if (moment().isBefore(moment(response.loginBlockedUntil))) {
                                return reject(`Login is blocked until ${moment(response.loginBlockedUntil).format('MMM DD YYYY hh:mm:ss A')}`);
                            } else {
                                response.loginAttemptsLeft = 5;
                                response.loginBlockedUntil = null;
                                await updateUserLoginTrials(findOfficerQuery,5, null);
                            }
                        }
                        var validation = await bcrypt.compare(req.body.loginPassword, response.loginPassword);
                        // var bytes  = CryptoJS.AES.decrypt(response.loginPassword, secretKey);
                        // var validation = bytes.toString(CryptoJS.enc.Utf8) == req.body.loginPassword;
                        if (validation) {
                            let origin = req.headers['Origin'];
                            if(origin == null)
                                origin= "";
                            let user= {
                                userId:response._id,
                                loginId:response._id,
                                loginType:response.loginType,
                                loginName:response.loginName,
                                lastLogin : response.currentLogin,
                                role:response.role,
                                loginEmail:response.loginEmail,
                                origin: origin
                            }		
                            await updateUserLoginTrials(findOfficerQuery,5, null);
                            await userModel.updateOne(findOfficerQuery, {$set: lastLoginUpdate},{upsert:false, multi:false});
                            const token = await jwt.createToken(user);
                            resolve({
                                loginId: response._id,
                                loginEmail: response.loginEmail,
                                loginName: response.loginName,
                                // appNo:response.appNo,
                                district: response.district,
                                //sro: response.sro,
                                role: response.role,
                                loginType: response.loginType,
                                lastLogin: response.currentLogin,
                                token: token
                            });
                        }else {
                            if(response.loginAttemptsLeft == undefined)
                                response.loginAttemptsLeft = 5;

			                let loginBlockedUntil = null;
                            let loginAttemptsLeft = response.loginAttemptsLeft - 1;
                            if (loginAttemptsLeft === 0) { // Set user blocking time
                                loginBlockedUntil = await new Date(moment().add('5', 'minutes'));
                            }
                            await updateUserLoginTrials(findOfficerQuery,loginAttemptsLeft, loginBlockedUntil);
                            reject("Email/Password incorrect")
                        }
                    } else {
                        reject("Email/Password incorrect")
                    }

                })
                .catch(err => {
                    console.log("DB error ::: ", err);
                    reject("Email/Password incorrect.")
                });
            } catch (err) {
                console.log("process error ::: ", err);
                reject(err);
            }
        });
    
};

exports.getLoginPassword = (req) => {
    return new Promise((resolve, reject) => {
        try {
        userModel.findOne({ loginEmail: { $regex: new RegExp(`^${req.params.loginEmail}$`), $options: 'i' } },
            { _id: 1, loginPassword: 1, loginEmail: 1, loginName: 1, loginType: 1, sroDistrict: 1, sroMandal: 1, sroOffice: 1, sroNumber: 1, role: 1,sro:1, district: 1, loginAttemptsLeft: 1, loginBlockedUntil: 1, lastLogin: 1, currentLogin: 1})
            .then(async response => {
                if (response) {
                    console.log(response)
                    var bytes  = CryptoJS.AES.decrypt(response.loginPassword, secretKey);
                    console.log(bytes)
                    response.loginPassword = bytes.toString(CryptoJS.enc.Utf8)
                    resolve(response);
                } else {
                    reject("Email not present")
                }

            })
            .catch(err => {
                console.log("DB error ::: ", err);
                reject("Email not present")
            });
        } catch (err) {
            console.log("process error ::: ", err);
            reject(err);
        }
    });

};

exports.resetPassword = (req) => {
    return new Promise(async (resolve, reject) => {
    try {
        if(!passwordPattern.test(req.body.newPassword))
            return reject('Password should meet the password policy.');
        if(req.body.newPassword==req.body.currentPassword){
            return reject('New Password should not be same as old password.')
        }

        let userDetails = await userModel.findOne({ loginEmail: req.user.loginEmail} );
        if(userDetails == null)
            return reject('User not found');

        var validation = await bcrypt.compare(req.body.currentPassword, userDetails.loginPassword);
        // var bytes  = CryptoJS.AES.decrypt(userDetails.loginPassword, secretKey);
        // var validation = bytes.toString(CryptoJS.enc.Utf8) == req.body.currentPassword;
        if(!validation){
            return reject('Invalid Current Password');
        }
        const myPlaintextPassword = req.body.newPassword;
        req.body.newPassword = await bcrypt.hash(myPlaintextPassword, saltRounds)
        //req.body.newPassword = CryptoJS.AES.encrypt(myPlaintextPassword, secretKey).toString();
        
        userModel.findOneAndUpdate( 
            { loginEmail: req.user.loginEmail }, 
            { $set: { loginPassword: req.body.newPassword } }
        ).then(details => resolve("Password changed successfully."))
        .catch(err => reject(err));
        
} catch (err) {
        console.log("Process Error :: ",  err);
        reject(err);
}
});

};

exports.logout = async(req,res) => {
    console.log("REMOVING")
    try {
        return res.status(200).json({ success: true, message: 'Token invalidated' });
    } catch (error) {
        
    }
}

exports.randomPasswordGenerator = (req) => {
    return new Promise(async (resolve, reject) => {
    try {
       
        let passwordGeneratorPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[a-zA-Z\d@$!%*#?&]{8,10}$/
        let userDetails = await userModel.find();
        console.log(userDetails.length);
        var wb = new xl.Workbook();
        var ws = wb.addWorksheet('Sheet 1');
        var headerStyle = wb.createStyle({
            font: {
              color: '#000000',
              size: 14,
              bold: true
            }
        });
        var rowsStyle = wb.createStyle({
            font: {
              color: '#000000',
              size: 12
            }
        });
        
        ws.cell(1, 1).string("UserEmail").style(headerStyle);
        ws.cell(1, 2).string("Password").style(headerStyle);
        for(let i=0; i < userDetails.length; i++){
            let password = new RandExp(passwordGeneratorPassword).gen();
            var ciphertext = CryptoJS.AES.encrypt(password, secretKey).toString();
            await userModel.findOneAndUpdate( 
                { loginEmail: userDetails[i].loginEmail }, 
                { $set: { loginPassword: ciphertext } }
            );
            ws.cell(i+2, 1).string(userDetails[i].loginEmail).style(rowsStyle);
            ws.cell(i+2, 2).string(password).style(rowsStyle);
        }   
        console.log("Success")
        wb.write("Password.xlsx");
        resolve("SUCCESS")
        
        } catch (err) {
                console.log("Process Error :: ",  err);
                reject(err);
        }
    });
};