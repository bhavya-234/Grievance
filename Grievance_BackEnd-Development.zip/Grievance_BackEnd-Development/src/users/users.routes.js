const express = require('express');
const router = express.Router();

const handler = require('./users.handler');

/*
exports.routesConfig = function (app) {
    // app.post('/api/signup', [handler.singup]);
    // app.post('/api/login', [handler.login]);
}
*/
router.post('/signup', [handler.singup]);
router.post('/login', [handler.login]);

module.exports = router;