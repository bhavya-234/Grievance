const mongoose = require("../../services/mongoose.service").mongoose;
const Schema = mongoose.Schema;

const otpSchema = new Schema({
	phoneNumber: { type: String },
    otp: { type: String },
	sendOtpCount:{type:Number},
	reSendOtpCount:{type:Number},
	otpVerificationCount:{type:Number},
	otpBlockedUntil: { type: Date, default: null },
},{timestamps:true});

module.exports = mongoose.model("otp", otpSchema, "otp");
