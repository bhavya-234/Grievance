const express = require('express');
const router = express.Router();

const users = require('../users/users.routes');
const officer = require('../officer/officer.routes');
const masterData = require('../masterData/masterData.routes');
const complaint = require('../complaint/complaint.routes');

router.use('/api/users',users);
router.use('/api/officer',officer);
router.use('/api/masterData',masterData);
router.use('/api/complaint',complaint);

module.exports = router;



