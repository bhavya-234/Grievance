class CommonFunctions{

    regxValidation = {
        isEmailAddress:function(str) {
            var pattern =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            return pattern.test(str);  
        },
        isNotEmpty:function (str) {
            var pattern =/\S+/;
            return pattern.test(str);  
        },
        isString: function (str){
            var pattern =/[A-Za-z0-9]+$/;
            return pattern.test(str);  
        },
        isNumber:function(str) {
            var pattern = /^\d+\.?\d*$/;
            return pattern.test(str); 
        },
        isSame:function(str1,str2){
            return str1 === str2;
        }
    }; 
}

module.exports = new CommonFunctions();