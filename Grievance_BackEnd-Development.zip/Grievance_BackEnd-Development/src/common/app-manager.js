const appManager = {
    //TODO: Global functions or parameters
};

exports.appManager = appManager;