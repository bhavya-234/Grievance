module.exports = { 
    STATUS_CHANGE_ACCEPTANCE: {
        "Submitted": ["New", "In Progress", "Completed"],
        "New": ["In Progress", "Auto-Escalated", "Completed"],
        "In Progress": ["Completed", "Auto-Escalated"],
        "Auto-Escalated": ["Completed", "Closed"],
        "Completed": ["Appealed to Higher Authority"],
        "Appealed to Higher Authority": ["Completed", "Closed"],
        "Closed": []
    }
  };