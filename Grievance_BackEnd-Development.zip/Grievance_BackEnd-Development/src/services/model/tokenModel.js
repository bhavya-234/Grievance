const mongoose = require('mongoose');


var TokenSchema = new mongoose.Schema({
	loginEmail:{type:String},
	loginType:{type:String},
	role:{type:String},
	token:{type:String}
},{timestamps:true})


module.exports = mongoose.model("token", TokenSchema);