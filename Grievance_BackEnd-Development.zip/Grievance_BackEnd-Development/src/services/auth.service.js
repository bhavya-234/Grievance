var jwt = require('jsonwebtoken');
const tokenModel = require('../services/model/tokenModel');
const userModel = require('../users/model/users.model');
const officerModel = require('../officer/model/officer.model');

const verifyUser = (req, res) => {
    try {
        return new Promise(function (resolve, reject) {
            const Header = req.headers["authorization"];
            if (typeof Header !== "undefined") {
                try {
                    const verified = jwt.verify(Header, process.env.JWT_SECRET_KEY);

                    if (verified) {
                        resolve(verified);
                    } else {
                        reject('Invalid User');
                    }
                } catch (error) {
                    reject('Invalid User');
                }
            } else {
                reject('Invalid User');
            }
        })
    } catch (e) {
        logger.warn(e.message);
        res.status(403).send({
            success: false,
            message: e.message,
            data: {}
        });
    }
}

const authUser = (req, res, next) => {
    verifyUser(req, res).then(result => {
        req.userId = result.userId;
        req.userTypeId = result.userTypeId;
        next();
    }).catch(error => {
        res.status(401).send({
            status: false,
            message: error,
            data: {}
        });
    });
}

const authGenerator = (min, max) => {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1) + min);
}

const createToken =async (user,refreshTokenUrl) => {
    let jwtSecretKey = process.env.JWT_SECRET_KEY;
	const expiresIn =process.env.JWT_EXP_IN;
	const token = jwt.sign(user,jwtSecretKey,{ expiresIn: expiresIn });
	let tokenSaveData = {loginEmail:user.loginEmail, loginType:user.loginType, role:user.role, token:token};
    let tokenModelObj = new tokenModel(tokenSaveData);
	await tokenModelObj.save();
	// return{
    //     token,
    //     expires: expiresIn,
    //     refreshTokenUrl:true
    // };
    return token;
};

function parseJwt (token) {
    return JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
}

const refreshToken = async (req,res)=>{
	try{
        const reqParams = req.params;
        let tokenHeader = req.headers['authorization'];
        const origin = req.headers['Origin'];
        if(origin == null)
            origin= "";
        if (tokenHeader) {
            let token = await tokenHeader.split(" ");

            let decoded = jwt.decode(token[1], process.env.JWT_SECRET_KEY);

            if(decoded.origin != origin)
                return res.status(401).json({ success: false, error: 'Unauthorized Access.' });
            
            let tokenObject = await tokenModel.findOne({loginEmail: decoded.loginEmail, token: token[1]});
            if(tokenObject==null)
                return res.status(401).json({ success: false, error: 'Unauthorized Access.' });

            if (decoded) {
                let currentTime = (new Date().getTime())/1000;

                let expiredVal = decoded.exp;
                const expiresIn = parseInt(process.env.JWT_RESET_EXP_IN.replace("m",""));
                expiredVal = expiredVal+expiresIn*60;
                if(expiredVal < currentTime)
                    return res.status(400).json({ success: false, error: 'Token Validity Expired.' });
                else
                {
                    delete decoded.exp;
                    delete decoded.iat;
                    let tokenUrl = req.protocol + "://" + req.get("host") + "/api/token/";
                    const token = await createToken(decoded, tokenUrl);
                    return res.status(200).send(
                    {	success:true,
                        data:token,
                        refreshTokenUrl:true
                    }
                    );
                }
            }else {
                return res.status(400).json({ success: false, error: 'Unauthorized Token' })
            }
        } else {
            return res.status(400).json({ success: false, error: 'Unauthorized Access' })
        }

	}catch(ex){
		res.status(500).send({
            success: false,
            error: ex.message
        });
	}

}

const tokenInvalidate = async function (req, res, next) {
    try{
        let tokenHeader = req.headers['authorization'];
        let origin = req.headers['Origin'];
        if(origin==null)
            origin = "";
        if (tokenHeader) {
            let token = await tokenHeader.split(" ");
            let decoded = jwt.decode(token[1], process.env.JWT_SECRET_KEY);
            if (decoded) {
                if(decoded.origin != origin)
                    return res.status(401).json({ success: false, error: 'Unauthorized Access.' });
                
                await tokenModel.findOneAndDelete({loginEmail: decoded.loginEmail, token: token[1]});
            }
            return next();
        }
        return res.status(401).json({ success: false, error: 'Unauthorized Access.' });
    }catch(ex){
        res.status(500).send({
            success: false,
            error: ex.message
        });
    }
}

/*Middleware for verifying the User JWT Token. */
const verifyUserjwt = async function (req, res, next) {
    return verifyJWTToken(req, res, next, "user");
}

/*Middleware for verifying the JWT Token. */
const verifyjwt = async function (req, res, next) {
    return verifyJWTToken(req, res, next, null);
}

/*Middleware for verifying the Officer JWT Token. */
const verifyOfficerJwt = async function (req, res, next) {
   return verifyJWTToken(req, res, next, "officer");
}

const verifyJWTToken = async function(req, res, next, userRole)
{
    try {
        let tokenHeader = req.headers['authorization'];
        let origin = req.headers['Origin'];
        if(origin==null)
            origin = "";
        if (tokenHeader) {
            let token = await tokenHeader.split(" ");
            let decoded = jwt.verify(token[1], process.env.JWT_SECRET_KEY);
            console.log(decoded)
            if (decoded) {
                req.user = decoded;
                let loginTypeVal = (decoded.loginType).toLowerCase();

                if(decoded.origin != origin)
                    return res.status(401).json({ success: false, error: 'Unauthorized Access.' });
                
                let tokenObject = await tokenModel.findOne({loginEmail: decoded.loginEmail, token: token[1]});
                if(tokenObject==null)
                    return res.status(401).json({ success: false, error: 'Unauthorized Access.' });

                if(userRole==null)
                {
                    let currentTime = (new Date().getTime())/1000;
                    if(decoded.exp < currentTime)
                        return res.status(401).json({ success: false, error: 'Token Validity Expired.' });
                    else    
                        return next();
                }
                else if(loginTypeVal==userRole)
                {
                    let userLoginData;
                    if(userRole=="officer")
                        userLoginData = await officerModel.findOne({loginEmail:decoded.loginEmail});
                    else if(userRole.toLowerCase()=="user")
                        userLoginData = await userModel.findOne({loginEmail:decoded.loginEmail});
                   
                    if(userLoginData==undefined || userLoginData == null)
                        return res.status(401).json({ success: false, error: 'Unauthorized Access.' })
                    
                    if(userRole=="officer" && userLoginData.role != decoded.role)
                        return res.status(401).json({ success: false, error: 'Unauthorized Access.' })
                    
                    let currentTime = (new Date().getTime())/1000;
                    if(decoded.exp < currentTime)
                        return res.status(401).json({ success: false, error: 'Token Validity Expired.' });
                    else    
                        return next();
                }
                else
                    return res.status(401).json({ success: false, error: 'Unauthorized Token. User Token required.' })
            } else {
            return res.status(401).json({ success: false, error: "Unauthorized Token. User Token required." })
            }      
        } else {
          return res.status(401).json({ success: false, error: 'Unauthorized Access.' })
        }
      } catch (error) {
        console.log("error ::: ", error);
        return res.status(401).json({ success: false, error: 'Session Expired, Please Login' })
      }
}


exports.authUser = authUser;
exports.authGenerator = authGenerator;
exports.createToken = createToken;
exports.refreshToken = refreshToken;
exports.verifyjwt= verifyjwt;
exports.verifyUserjwt = verifyUserjwt;
exports.verifyOfficerJwt = verifyOfficerJwt;
exports.tokenInvalidate = tokenInvalidate;