const handler = require('./complaint.handler');
const fileUpload = require('../common/fileUpload');
const { verifyjwt, verifyOfficerJwt } = require('../services/auth.service');

const express = require('express');
const router = express.Router();
/*
exports.routesConfig = (app) => {
    // app.post('/api/complaint/create', fileUpload.uploadStore.fields([
    //     { name: 'image' }]),[handler.createComplaint]);
    // // app.get('/api/complaints/search/:page/:key', [handler.search]);
    // app.get('/api/complaints/:page/:status/:officerId', verifyOfficerJwt, [handler.getComplaints]);
    // app.get('/api/complaint/:complaintNo', verifyOfficerJwt, [handler.getComplaintsByNo]);
    // app.get('/api/complaint/user/:complaintNo', [handler.getComplaintsByNo]);
    // app.post('/api/complaint/report/:complaintNo', verifyOfficerJwt, [handler.reportToHA]);
    // app.post('/api/complaint/report/user/:complaintNo', [handler.reportToHA]);
    // app.put('/api/complaints/:complaintId', verifyOfficerJwt, [handler.updateComplaints]);
    // app.put('/api/complaints/user/:complaintId', [handler.updateComplaints]);
    // app.post('/api/fileUpload', fileUpload.uploadStore.fields([
    //     { name: 'image' }]), verifyOfficerJwt, [handler.fileUpload]);
    // app.post('/api/fileUpload/user', fileUpload.uploadStore.fields([
    //     { name: 'image' }]), [handler.fileUpload]);
    // app.get('/api/overview/complaints/:officerId', verifyOfficerJwt, [handler.complaintOverview]);
	// //app.put('/api/complaint/resetPassword',[handler.reset])
	//app.put('/api/complaint/resetPassword',[handler.reset])
}
*/

router.post('/create', fileUpload.uploadStore.fields([
    { name: 'image' }]),[handler.createComplaint]);
router.get('/getComplaints/:page/:status/:officerId', verifyOfficerJwt, [handler.getComplaints]);
router.get('/getComplaintByNumber/:complaintNo', verifyOfficerJwt, [handler.getComplaintsByNo]);
router.get('/user/:complaintNo', [handler.getComplaintsByNo]);
router.post('/report/:complaintNo', verifyOfficerJwt, [handler.reportToHA]);
router.post('/report/user/:complaintNo', [handler.reportToHA]);
router.put('/updateComplaint/:complaintId', verifyOfficerJwt, [handler.updateComplaints]);
router.put('/user/updateComplaint/:complaintId', [handler.updateComplaints]);
router.post('/fileUpload', fileUpload.uploadStore.fields([
    { name: 'image' }]), verifyOfficerJwt, [handler.fileUpload]);
router.post('/fileUpload/user', fileUpload.uploadStore.fields([
    { name: 'image' }]), [handler.fileUpload]);
router.get('/overview/:officerId', verifyOfficerJwt, [handler.complaintOverview]);
router.post('/sendSMS',[handler.sendSMS]);
router.post('/resendSMS',[handler.resendSMS]);
router.post('/verifySMS',[handler.verifySMS]);


module.exports = router;
