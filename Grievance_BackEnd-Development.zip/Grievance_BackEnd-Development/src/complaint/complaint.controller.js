const complaintModel = require('./model/complaint.model');
const masterModel = require('../masterData/model/masterData.model');
const officerModel = require('../officer/model/officer.model');
const otpModel = require('../otp/model/otp.model');
const mailUtil = require("../common/mail");
const { xml2json } = require('xml-js');
const axios = require('axios')
const moment = require('moment');


var cron = require('node-cron');
const { regxValidation } = require('../common/commonFunctions');
const { STATUS_CHANGE_ACCEPTANCE } = require('../common/constants');
//0 0 0 * * *


const SMSurl = "http://igrs.ap.gov.in:7004/SMS_Service/SmsService?wsdl";

// const axios = require('axios');
cron.schedule('* * * * *', async () => {
    console.log('closing Scheduler running at: ', new Date());
    const fifteenDaysAgo = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
    console.log('2days back date: ', fifteenDaysAgo);
    //let completedList = await complaintModel.find({ updatedAt: { "$lte": fifteenDaysAgo }, complaintStatus: "Compleated" });
    //console.log("dr------",drList);
    await complaintModel.updateMany({ updatedAt: { "$lte": fifteenDaysAgo }, complaintStatus: "Completed" }, { $set: { complaintStatus: "Closed", updatedAt: new Date() } });

});
cron.schedule('* * * * *', async () => {
    try {
        console.log('Scheduler running at: ', new Date());
        const fifteenDaysAgo = new Date(Date.now() - 15 * 24 * 60 * 60 * 1000);
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        console.log('15days back date: ', fifteenDaysAgo);
        let drList = await complaintModel.find({ createdAt: { "$lte": fifteenDaysAgo }, complaintStatus:{$in:["Submitted","In Progress"]} , actionUnder: "DR" });
        let digList = await complaintModel.find({ createdAt: { "$lte": thirtyDaysAgo }, complaintStatus: {$in:["Auto-Escalated"]}, actionUnder: "DIG" });
        let tempDigList = await complaintModel.find({ updatedAt: { "$lte": fifteenDaysAgo }, complaintStatus: {$in:["Appealed to Higher Authority"]}, actionUnder: "DIG" });
        console.log('---drlist-----',drList);
        console.log('---diglist-----',digList);
        console.log('---tempDigList-----',tempDigList);
        if (drList.length > 0) {
            await complaintModel.updateMany({ createdAt: { "$lte": fifteenDaysAgo }, complaintStatus: {$in:["Submitted","In Progress"]}, actionUnder: "DR" }, { $set: { actionUnder: "DIG",complaintStatus:"Auto-Escalated", updatedAt: new Date() } });
            drList.filter(async complaint=>{
                let digDetails = await officerModel.find({ role: "DIG" ,subDistrict:{$in:[complaint.district]}});
                let reqObj = {};
                reqObj.toMail = digDetails[0].loginEmail;
                reqObj.subject = "Sub: Grievance Auto-Escalated !!";
                reqObj.message = `Dear Officer,<br>
                A Grievance with ID – <b>${complaint.complaintNo}</b> has been raised by Mr/Ms. ${complaint.personName} .
                Kindly check.<br>
                The SLA for any Grievance is 15 days, if exceeded, it will auto-escalate to higher authorities!!!<br><br><br>`
                await mailUtil.sentMail(reqObj);
            })
            
        }
        if (digList.length > 0) {
            let igDetails = await officerModel.find({ role: "IG" });
            await complaintModel.updateMany({ createdAt: { "$lte": thirtyDaysAgo }, complaintStatus: {$in:"Auto-Escalated"}, actionUnder: "DIG" }, { $set: { actionUnder: "IG", updatedAt: new Date() } });
            digList.filter(async complaint=>{
                let reqObj = {};
                reqObj.toMail = igDetails[0].loginEmail;
                reqObj.subject = "Sub: Grievance Auto-Escalated !!";
                reqObj.message = `Dear Officer,<br>
                A Grievance with ID – <b>${complaint.complaintNo}</b> has been raised by Mr/Ms. ${complaint.personName}.
                Kindly check.<br>
                The SLA for any Grievance is 15 days, if exceeded, it will auto-escalate to higher authorities!!!<br><br><br>`
                await mailUtil.sentMail(reqObj);
            })
        }
        if (tempDigList.length > 0) {
            let igDetails = await officerModel.find({ role: "IG" });
            await complaintModel.updateMany({ updatedAt: { "$lte": fifteenDaysAgo }, complaintStatus: {$in:["Appealed to Higher Authority"]}, actionUnder: "DIG" }, { $set: { actionUnder: "IG", updatedAt: new Date(),complaintStatus:"Auto-Escalated" } });
            tempDigList.filter(async complaint=>{
                let reqObj = {};
                reqObj.toMail = igDetails[0].loginEmail;
                reqObj.subject = "Sub: Grievance Auto-Escalated !!";
                reqObj.message = `Dear Officer,<br>
                A Grievance with ID – <b>${complaint.complaintNo}</b> has been raised by Mr/Ms. ${complaint.personName}.
                Kindly check.<br>
                The SLA for any Grievance is 15 days, if exceeded, it will auto-escalate to higher authorities!!!<br><br><br>`
                await mailUtil.sentMail(reqObj);
            })
        }
        // await complaintModel.updateMany({ createdAt: { "$lte": fifteenDaysAgo }, complaintStatus: "PENDING", actionUnder: "DR" }, { $set: { actionUnder: "DIG", updatedAt: new Date() } });
        // await complaintModel.updateMany({ updatedAt: { "$lte": fifteenDaysAgo }, complaintStatus: "PENDING", actionUnder: "DIG" }, { $set: { actionUnder: "IG", updatedAt: new Date() } });

    } catch (error) {
        console.log(`Cron Job fails at ${new Date()}with error: ${error} `)
    }

});

exports.createComplaint = async (req) => {
    return new Promise(async (resolve, reject) => {
    try {
        
        let reqObj = req.body;
        let masterData = await masterModel.findOne({districtName: req.body.district, mandalName: req.body.mandal, sroName: req.body.sro}, { revDistCode: 1 });
        if(!masterData || masterData.length == 0){
            throw new Error('Invalid Input');
        }
        // if(reqObj.otpID == null)
        //     return reject("please validate your mobile number before submitting the grievance")
        // let filters = {_id: reqObj.otpID}
        // const otpVerify = await otpModel.findOne(filters);
        //     if(otpVerify == null){
        //         return reject("please validate your mobile number before submitting the grievance")
        //     }
        //     if(otpVerify !== null && otpVerify.otp == reqObj.otp){
        //         await otpModel.deleteOne(filters);
        //     }
        //     else
        //     {
        //         return reject("please validate your mobile number before submitting the grievance.")
        //     }
        //let districtCode = await masterModel.findOne({ districtName: req.body.district }, { revDistCode: 1 });

        // var rNum = Math.floor(10000 + Math.random() * 90000);
        //let code = districtCode.revDistCode.length == 2 ? `${districtCode.revDistCode}` : `0${districtCode.revDistCode}`
        // let year = new Date().toLocaleDateString('en', { year: '2-digit' })
        let year = new Date().getFullYear();
        let tempNum = Date.now().toString();
        tempNum = tempNum.substring(4, tempNum.length);
        //let graviance = await complaintModel.findOne({ "complaintNo": { $regex: `GR${year}${code}` } }).sort({ createdAt: -1 }).limit(1);
        reqObj.complaintNo = `GR${year}${tempNum}`;
        // if (graviance) {
        //     let tempNo = graviance.complaintNo.slice(-5);
        //     tempNo = parseInt(`1${tempNo}`) + 1;
        //     tempNo = tempNo.toString().slice(-5);
        //     reqObj.complaintNo = `GR${year}${code}${tempNo}`;
        // } else {
        //     reqObj.complaintNo = `GR${year}${code}00001`;
        // }
        
        reqObj.createdAt=new Date();
        delete reqObj.otp;
        delete reqObj.otpID;
            complaintModel.create(reqObj)
                .then(async response => {
                    let mailObj = {};
                    let userDetails= await officerModel.find({district:req.body.district,role:"DR"});
                    mailObj.toMail = reqObj.email;
                    mailObj.subject = "Sub: Grievance Submission Successful !! ";
                    mailObj.message = `Dear User <br> Your application with Grievance ID No. <b>${reqObj.complaintNo}</b> has been submitted successfully. Your grievance will be redressed within 15 days. <br>
                    Thank You!<br><br><br>`
                    await mailUtil.sentMail(mailObj);
                    let DrMailObj={};
                    DrMailObj.toMail = userDetails[0].loginEmail;
                    DrMailObj.subject = "Grievance submitted";
                    DrMailObj.message = `Dear Officer (${userDetails[0].loginName}), <br>
                    A Grievance with ID – <b>${reqObj.complaintNo}</b> has been raised by Mr/Ms. ${req.body.personName} on ${new Date().toDateString()}.
                    Kindly check.
                    <br>
                    The SLA for any Grievance is 15 days, if exceeded, it will auto-escalate to higher authorities!!!<br><br><br>`
                    await mailUtil.sentMail(DrMailObj);
                    resolve({ complaintNo: reqObj.complaintNo });
                }).catch(err => reject(err));
       
    } catch (err) {
        console.log("process error" , err);
        // throw err;
        reject(err);
    }
});
};

exports.fileUpload = (req) => {
    return new Promise((resolve, reject) => {
    try {
        console.log("coming here");
        const [local, rest] = req.get("host").split(":");
        let fileName =  req.files.image[0].filename;
        let fileNamesSplit = fileName.split('.');
        let validFileExtensions = ["jpg", "jpeg", "bmp", "png", "pdf"];
        if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
            throw Error("Invalid File");
        }
        let Url =
            local === "localhost"
                ? req.protocol + "://" + req.get("host") + "/complaints"
                : "http://" + req.get("host") + "/complaints";
        let tempObj = {
            fileName: req.files.image[0].filename,
            filePath: req.files.image[0].path,
            downloadLink: `${Url}/${req.files.image[0].filename}`,
            timeStamp: new Date()
        }
        
            resolve(tempObj);
        


    } catch (err) {
        console.log("process error" , err);
        // throw err;
        reject(err)
    }
})
}
exports.search = (req) => {
    return new Promise((resolve, reject) => {
    try {
        
            let perPage = 10;
            complaintModel.find({
                $or: [{ gravianceClassification: { $regex: req.params.key, $options: 'i' } },
                { complaintNo: { $regex: req.params.key, $options: 'i' } }
                ]
            },
                { createdAt: 1, gravianceClassification: 1, subject: 1, complaintNo: 1, complaintStatus: 1, actionUnder: 1, updatedAt: 1 })
                .sort({ updatedAt: -1 })
                .limit(perPage)
                .skip(perPage * (req.params.page - 1))
                .then(async response => {
                    if (response) {
                        let count = await complaintModel.find({
                            $or: [{ gravianceClassification: { $regex: req.params.key, $options: 'i' } },
                            { complaintNo: { $regex: req.params.key, $options: 'i' } }
                            ]
                        },
                        { createdAt: 1, gravianceClassification: 1, subject: 1, complaintNo: 1, complaintStatus: 1, actionUnder: 1, updatedAt: 1 }).count()

                        let finalResult = {
                            totalCount: count,
                            data: response
                        }
                        resolve(finalResult);
                    } else {
                        reject("Something went wrong");
                    }

                })
                .catch(err => reject(err));
        
    } catch (error) {
        console.log("process error" ,err);
        reject(err)
    }
})
}
exports.getComplaints = async (req) => {
    return new Promise(async (resolve, reject) => {
    try {
       
            let condition = {};
            let perPage = 10;
            if (req.params.status !== "ALL") {
                condition = { complaintStatus: req.params.status };
            }
            // if (req.params.officerId && req.params.officerId.length > 0 ) {
            //     var officerDetails= await officerModel.find({ _id: req.params.officerId });
            //     if (officerDetails.length>0 && officerDetails[0].role=="DIG"){
                    
            //         condition.district ={$in:officerDetails[0].subDistrict};
            //     }
            // }
            let userData = req.user;
            if (userData && userData.loginType.toLowerCase() == "officer" ) {
                if(userData.userId != req.params.officerId){
                    return reject("Token & Officer Id are not matching")
                }
                var officerDetails= await officerModel.find({ _id: userData.userId });
                if (officerDetails.length>0 && officerDetails[0].role=="DIG"){
                    
                    condition.district ={$in:officerDetails[0].subDistrict};
                }
                else if (officerDetails.length>0 && officerDetails[0].role=="DR"){
                    
                    condition.district =officerDetails[0].district;
                }
            }
            // if (req.query.district && req.query.district.length > 0 && regxValidation.isString(req.query.district)) {
            //     condition.district = req.query.district;
            // }
            if (req.query.sro && req.query.sro.length > 0) {
                condition.sro = req.query.sro;
            }
            if(req.query.search && req.query.search.length > 0 && regxValidation.isString( req.query.search)) {
                condition.gravianceClassification={ $regex: req.query.search, $options: 'i' };
            }

            complaintModel.find(condition, { createdAt: 1, gravianceClassification: 1, subject: 1, complaintNo: 1, complaintStatus: 1, actionUnder: 1, userType: 1, updatedAt: 1 })
                .sort({ updatedAt: -1 })
                .limit(perPage)
                .skip(perPage * (req.params.page - 1))
                .then(async response => {
                    if (response) {
                        let count = await complaintModel.find(condition, { createdAt: 1, gravianceClassification: 1, subject: 1, complaintNo: 1, complaintStatus: 1, actionUnder: 1, userType: 1, updatedAt: 1 }).count()

                        let finalResult = {
                            totalCount: count,
                            data: response
                        }
                        resolve(finalResult);
                    } else {
                        reject("Something went wrong");
                    }

                })
                .catch(err => reject(err));
        
    } catch (err) {
        console.log("process error" , err);
        reject(err)
    }
});
};
exports.getComplaintsByNo = async (req) =>  {
    return new Promise(async (resolve, reject) => {
    try {
        let filter = {
            complaintNo: req.params.complaintNo
        }
        if(req.user && req.user.loginType.toLowerCase() == "officer"){
            let userLoginData = await officerModel.findOne({loginEmail:req.user.loginEmail});
            if(!userLoginData || !userLoginData.role){
                throw Error("Invalid User");
            }
            switch (userLoginData.role.toUpperCase()) {
                case "DR":
                    filter.district = userLoginData.district;
                    break;
                case "DIG":
                    filter.district = {
                        $in:userLoginData.subDistrict
                    };
                    break;
                case "IG":
                    break
                default:
                    throw Error("Invalid Role");
            }
        }
       
            complaintModel.find(filter)
                .populate({ path: "repliedBy", select: "loginName role district loginEmail" })
                .then(response => {
                    if (response) {
                        resolve(response);
                    } else {
                        reject("failed to compliant details")
                    }

                })
                .catch(err => reject(err));
        
    } catch (err) {
        console.log("process error" ,err);
        // throw err;
        reject(err)
    }
});
};
exports.updateComplaints = async (req) => {
    return new Promise(async (resolve, reject) => {
    try {
        let filter = {
            complaintNo: req.params.complaintId
        }
        console.log(req.user);
        if(req.user && req.user.loginType.toLowerCase() == "officer"){
            let userLoginData = await officerModel.findOne({loginEmail:req.user.loginEmail});
            if(!userLoginData || !userLoginData.role){
                throw Error("Invalid User");
            }
            switch (userLoginData.role.toUpperCase()) {
                case "DR":
                    filter.district = userLoginData.district;
                    break;
                case "DIG":
                    filter.district = {
                        $in:userLoginData.subDistrict
                    };
                    break;
                case "IG":
                    break
                default:
                    throw Error("Invalid Role");
            }
        }
    
      
            try {
                let condition
                req.body.updatedAt = new Date;
                if (req.body.commentsList) {
                    req.body.commentsList[0].addedAt = new Date;
                    condition = { $push: { commentsList: req.body.commentsList[0] } }
                    let complaintData = await complaintModel.findOne(filter);
                    if(complaintData == null || complaintData.length == 0){
                        reject("UnAuthrozed User")
                    }
                    await complaintModel.findOneAndUpdate(filter, condition)
                    if (req.body.commentsList[0].role!=="USER"){
                        let mailObj = {};
                        let userDetails= await complaintModel.find(filter)
                        if(userDetails == null || userDetails.length == 0){
                            throw Error("InValid User")
                        }
                        mailObj.toMail = userDetails[0].email;
                        mailObj.subject = "Sub: Grievance Redressed Successful !! ";
                        mailObj.message = `Dear User (${userDetails[0].personName}), <br>
                        Your application with Grievance ID No. <b>${req.params.complaintId}</b> has been redressed. Please check the  application for more details.
                        <br>
                        Thank You!<br><br><br>`
                        await mailUtil.sentMail(mailObj);
                    }
                    delete req.body.commentsList;
                }
                if (req.body) {
                    console.log(filter);
                    let complaintData = await complaintModel.findOne(filter);
                    if(complaintData == null || complaintData.length == 0){
                        reject("UnAuthrozed User")
                    }
                    if(complaintData.complaintStatus != null && !STATUS_CHANGE_ACCEPTANCE[complaintData.complaintStatus].includes(req.body.complaintStatus)){
                        return reject("Complaint Status can't be changed")
                    }
                    // if(complaintData.complaintStatus == "Closed" ||(complaintData.complaintStatus == "Completed" && req.body.complaintStatus !=  'Appealed to Higher Authority')){
                    //     reject("Complaint Status can't be changed")
                    // }
                    complaintModel.findOneAndUpdate(filter, { $set: req.body })
                        .then(details => resolve("Complaint updated succesfully"))
                        .catch(err => reject(err));
                } else {
                    resolve("Complaint updated succesfully")
                } 
            } catch (error) {
                reject(error);
            }
        
    } catch (err) {
        console.log("process error" , err);
        reject(err)
    }
});
};

exports.reportToHA = async (req) => {
    return new Promise(async (resolve, reject) => {
    try {
        let filter = {
            complaintNo: req.params.complaintNo
        }
        if(req.user && req.user.loginType.toLowerCase() == "officer"){
            let userLoginData = await officerModel.findOne({loginEmail:req.user.loginEmail});
            if(!userLoginData || !userLoginData.role){
                throw Error("Invalid User");
            }
            switch (userLoginData.role.toUpperCase()) {
                case "DR":
                    filter.district = userLoginData.district;
                    break;
                case "DIG":
                    filter.district = {
                        $in:userLoginData.subDistrict
                    };
                    break;
                case "IG":
                    break
                default:
                    throw Error("Invalid Role");
            }
        }
        
     
            console.log("FILTER IS ", filter);
            let complaintDetails = await complaintModel.find(filter);
            if (complaintDetails[0].isReportedToHA || complaintDetails[0].actionUnder == "IG") {
                return reject("Already reported to higher authority")
            } else if(complaintDetails[0].complaintStatus != null && !STATUS_CHANGE_ACCEPTANCE[complaintDetails[0].complaintStatus].includes("Appealed to Higher Authority")){
                return reject("Invalid Complaint Status Change")
            }
            else {
                let reqObj = {
                    updatedAt: new Date,
                    isReportedToHA: true,
                    complaintStatus: "Appealed to Higher Authority"
                }
                let mailObj = {};
                    mailObj.toMail = complaintDetails[0].email;
                    mailObj.subject = "Sub: Grievance Redressed Successful !! ";
                    mailObj.message = `Dear User (${complaintDetails[0].personName}), <br>
                    Your application with Grievance ID No. <B>${req.params.complaintNo}</B> has been appealed to higher authority successfully.
                    <br>
                    Thank You!
                    <br><br><br>`
                    await mailUtil.sentMail(mailObj);
                //${new Date(complaintDetails[0].createdAt.substring(0, 10)).toDateString()}
                if (complaintDetails[0].actionUnder == "DR") {
                    reqObj.actionUnder = "DIG"
                    let digDetails = await officerModel.find({ role: "DIG" ,subDistrict:{$in:[complaintDetails[0].district]}});
                    let mailReqObj = {};
                    mailReqObj.toMail = digDetails[0].loginEmail;
                    mailReqObj.subject = "Sub: Grievance appeal Successful !!";
                    mailReqObj.message = `Dear Officer,<br>
                    A Grievance with ID – <b>${complaintDetails[0].complaintNo}</b> has been raised by Mr/Ms. ${complaintDetails[0].complaintNo}.
                    has been appealed by user. Kindly check.<br><br><br>`
                    await mailUtil.sentMail(mailReqObj);
                } else if (complaintDetails[0].actionUnder == "DIG") {
                    reqObj.actionUnder = "IG"
                    let digDetails = await officerModel.find({ role: "IG"});
                    let mailReqObj = {};
                    mailReqObj.toMail = digDetails[0].loginEmail;
                    mailReqObj.subject = "Sub: Grievance appeal Successful !!";
                    mailReqObj.message = `Dear Officer,<br>
                    A Grievance with ID – <b>${complaintDetails[0].complaintNo}</b> has been raised by Mr/Ms. ${complaintDetails[0].complaintNo}.
                        has been appealed by user. Kindly check.<br><br><br>`
                    await mailUtil.sentMail(mailReqObj);
                }

                complaintModel.findOneAndUpdate({ complaintNo: req.params.complaintNo }, { $set: reqObj })
                    .then(details => resolve("Reported to Higher authority succesfully"))
                    .catch(err => reject(err));

            }
        
    } catch (err) {
        console.log("process error" , err);
        reject(err)
    }
});
}

exports.complaintOverview = async (req) => {
    return new Promise(async (resolve, reject) => {
    try {
       
            console.log("12");
            console.log(req.user);
            if(!req.user || req.user.userId != req.params.officerId){
                reject("Token & Officer Id are not matching")
            }
            let officerDetails = await officerModel.find({ _id:req.params.officerId});
            let totalCondition={};
            let newCondition={};
            let inprogressCondition={};
            let completedCondition={};
            let autoEscalatedCondition ={};
            let reportedToHACondition = {};
            let closedCondition = {};
            if (officerDetails[0].role=="DR") {
                totalCondition.district={$in:[officerDetails[0].district]}
                newCondition ={
                    district:{$in:[officerDetails[0].district]},
                    complaintStatus:{$in:["Submitted"]},
                };
                inprogressCondition= {
                    district:{$in:[officerDetails[0].district]},
                    complaintStatus:{$in:["In Progress"]},
                };
                completedCondition ={
                    district:{$in:[officerDetails[0].district]},
                    complaintStatus:{$in:["Completed"]},
                }
                reportedToHACondition = {
                    district:{$in:[officerDetails[0].district]},
                    complaintStatus:{$in:["Appealed to Higher Authority"]},
                }
                autoEscalatedCondition = {
                    district:{$in:[officerDetails[0].district]},
                    complaintStatus:{$in:["Auto-Escalated"]},
                }
                closedCondition = {
                    district:{$in:[officerDetails[0].district]},
                    complaintStatus:{$in:["Closed"]},
                }
            } else if (officerDetails[0].role=="DIG") {
                totalCondition.district={
                    $in:officerDetails[0].subDistrict
                }
                newCondition ={
                    district:{$in:officerDetails[0].subDistrict},
                    complaintStatus:{$in:["Submitted"]},
                }
                completedCondition ={
                    district:{$in:officerDetails[0].subDistrict},
                    complaintStatus:{$in:["Completed"]},
                }
                inprogressCondition= {
                    district:{$in:officerDetails[0].subDistrict},
                    complaintStatus:{$in:["In Progress"]},
                };
                reportedToHACondition = {
                    district:{$in:officerDetails[0].subDistrict},
                    complaintStatus:{$in:["Appealed to Higher Authority"]},
                }
                autoEscalatedCondition = {
                    district:{$in:officerDetails[0].subDistrict},
                    complaintStatus:{$in:["Auto-Escalated"]},
                }
                closedCondition = {
                    district:{$in:officerDetails[0].subDistrict},
                    complaintStatus:{$in:["Closed"]},
                }
            }else{
                newCondition ={
                    complaintStatus:{$in:["Submitted"]},
                };
                inprogressCondition= {
                    complaintStatus:{$in:["In Progress"]},
                };
                completedCondition ={
                    complaintStatus:{$in:["Completed"]},
                }
                reportedToHACondition = {
                    complaintStatus:{$in:["Appealed to Higher Authority"]},
                }
                autoEscalatedCondition = {
                    complaintStatus:{$in:["Auto-Escalated"]},
                }
                closedCondition = {
                    complaintStatus:{$in:["Closed"]},
                }
            }
            let responce= {
                totalCompaints: await complaintModel.find(totalCondition).count(),
                newComplaints: await complaintModel.find(newCondition).count(),
                inProgrss: await complaintModel.find(inprogressCondition).count(),
                completedComplaints: await complaintModel.find(completedCondition).count(),
                autoEscalated: await complaintModel.find(autoEscalatedCondition).count(),
                reportedToHA: await complaintModel.find(reportedToHACondition).count(),
                closed: await complaintModel.find(closedCondition).count(),
            }
            resolve(responce)
       
    } catch (err) {
        console.log("process error" , err);
        // throw err;
        reject(err)
    }
});
}

exports.sendSMS = async (req ) => {
    return new Promise(async (resolve, reject) => {
        try {
            
            let otpData = await otpModel.findOne({phoneNumber: req.body.phoneNumber});
            if(otpData != null && (otpData.reSendOtpCount == 0 || otpData.sendOtpCount == 0) && otpData.otpBlockedUntil != null && moment().isBefore(moment(otpData.otpBlockedUntil))){
                return reject(`Otp is blocked until ${moment(otpData.otpBlockedUntil).format('MMM DD YYYY hh:mm:ss A')}`)
            } else if(otpData?.sendOtpCount == 0 && otpData.otpBlockedUntil == null){
                
                let otpBlockedUntil = await new Date(moment().add('5', 'minutes'));
                await otpModel.updateMany({phoneNumber: req.body.phoneNumber}, { $set: { otpBlockedUntil: otpBlockedUntil } });
                return reject("You have exceeded OTP send attempts.Please try after 5 mins.")
            }

            const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
            console.log(otp)

            let xmlString = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '+
                'xmlns:nic="http://nic.com/"><soapenv:Header/><soapenv:Body><nic:sendSms_New>'+
                '<phoneNo>'+req.body.phoneNumber+'</phoneNo><content>'+`Your OTP to access Registration and Stamps Govt of AP Portal is `+otp+'</content>'+
                '<templateId>'+`1007176258326536442`+'</templateId></nic:sendSms_New></soapenv:Body>'+
                '</soapenv:Envelope>';
            let response = await axios({
                url:SMSurl,
                data: xmlString,
                method: 'POST',
                headers: {
                    'Accept': 'text/xml',
                    'Content-Type': 'text/xml'
                }
            })
            console.log(" response ::: ", response.data)
            
            let otpDbResponse = await otpModel.updateOne({phoneNumber: req.body.phoneNumber}, {
                phoneNumber: req.body.phoneNumber,
                otp: otp,
                sendOtpCount: otpData != null && otpData.sendOtpCount != null && otpData.sendOtpCount != 0 ? otpData.sendOtpCount - 1 : 5,
                reSendOtpCount: 5,
                otpVerificationCount: 5,
                otpBlockedUntil: null
            }, {upsert:true, multi:false});
            if(otpDbResponse.upsertedId == null){
                otpDbResponse = otpData;
            } else {
                otpDbResponse._id = otpDbResponse.upsertedId;
            }
            // let otpDbResponse = await otpModel.create({
            //     phoneNumber: req.body.phoneNumber,
            //     otp: otp,
            //     reSendOtpCount: 5,
            //     otpVerificationCount: 5
            // })
            console.log(otpDbResponse)
            resolve({
                id: otpDbResponse._id
            })
        } catch (error) {
            console.log("error :::: ", error);
            reject(error)
        }
    });
}

exports.resendSMS = async (req ) => {
    return new Promise(async (resolve, reject) => {
        try {
            const reqBody = req.body;
            const filters = { _id: reqBody.id };
            const otpDbData = await otpModel.findOne(filters);
            if(otpDbData == null ){
                return reject("OTP data is not present .Please try again with send OTP.")
            } else if(otpDbData.reSendOtpCount == 0){
                // await otpModel.deleteOne(filters);
                if( otpDbData.otpBlockedUntil != null && moment().isBefore(moment(otpDbData.otpBlockedUntil))){
                    return reject(`Otp is blocked until ${moment(otpDbData.otpBlockedUntil).format('MMM DD YYYY hh:mm:ss A')}`)
                }
                let otpBlockedUntil = await new Date(moment().add('5', 'minutes'));
                await otpModel.updateMany(filters, { $set: { otpBlockedUntil: otpBlockedUntil } });
                return reject("You have exceeded OTP resend attempts.Please try after 5 mins.")
            }
            const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
            console.log(otp)

            let xmlString = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '+
                'xmlns:nic="http://nic.com/"><soapenv:Header/><soapenv:Body><nic:sendSms_New>'+
                '<phoneNo>'+otpDbData.phoneNumber+'</phoneNo><content>'+`Your OTP to access Registration and Stamps Govt of AP Portal is `+otp+'</content>'+
                '<templateId>'+`1007176258326536442`+'</templateId></nic:sendSms_New></soapenv:Body>'+
                '</soapenv:Envelope>';
            let response = await axios({
                url:SMSurl,
                data: xmlString,
                method: 'POST',
                headers: {
                    'Accept': 'text/xml',
                    'Content-Type': 'text/xml'
                }
            })
            console.log(" response ::: ", response.data)
            otpDbData.reSendOtpCount = otpDbData.reSendOtpCount-1;
            otpDbData.otpVerificationCount = 5;
            otpDbData.otp = otp;
            await otpModel.findOneAndUpdate(filters, otpDbData)
            
            resolve({
                id: otpDbData._id
            })
        } catch (error) {
            console.log("error :::: ", error);
            reject(error)
        }
    });
}

exports.otpValidation = async (req,res) => {
    return new Promise(async (resolve, reject) => {
        try {
            const reqBody = req.body;
            const filters = { _id: reqBody.id};
            const otpVerify = await otpModel.findOne(filters);
            if(otpVerify == null){
                reject("OTP data is not present .Please try again with send OTP.")
            }
            if(otpVerify !== null && otpVerify.otp == reqBody.otp && otpVerify.otpVerificationCount != 0){
                // verify = await otpModel.deleteOne(filters)
                resolve(`OTP verified successfully.`)
            }else {		
                let otpVerificationCount = parseInt(otpVerify.otpVerificationCount);
                if(otpVerificationCount === 0){
                    reject(`You have exceeded OTP verification attempts.Please try again with re-send OTP.`);			
                }else{
                    await otpModel.findOneAndUpdate({_id:reqBody.id},{$set:{otpVerificationCount:otpVerificationCount-1}});
                    reject(`OTP is invalid, you have only ${otpVerificationCount-1} attempts.`)
                }
            }
        } catch (err) {
            console.log("Process Error" , err);
            reject(`Internal server error. Please try after sometime.`)
        }
    });
};