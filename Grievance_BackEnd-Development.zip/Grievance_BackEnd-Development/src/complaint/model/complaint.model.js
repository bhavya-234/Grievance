const mongoose = require("../../services/mongoose.service").mongoose;
const Schema = mongoose.Schema;

const officerSchema = new Schema({
    // appNo: { type: String , default: Date.now(), unique : true},
    repliedBy:{
        type:Schema.Types.ObjectId,
        ref:'officers'
    },
    complaintNo:{
        type: String, unique: true
    },
    personName:{type:String},
    phoneNumber: { type: String },
    email: { type: String },
    district: { type: String },
    mandal: { type: String },
    sro: { type: String },
	districtRegisterName:{type:String},
	gravianceClassification:{
        type:String,
        required: true,
        enum: ["REGISTRATION", "EC", "CC", "MARKET VALUE", "SALE OF STAMPS", "FRADULENT REGISTRATIONS", "PROHIBITED PROPERTIES", 
        "EDIT INDEX", "IMPOUNDING", "MARKET ANOMALY", "NOTARY", "ANY OTHER"]
    },
	subject:{type:String},
	description:{type:String},
    documents:{ type: Array },
    actionUnder: { type: String , default:"DR"},
    userType: { type: String , default:null},
    createdAt: { type: Date },
    updatedAt: { type: Date, default: Date.now },
    complaintStatus: { type: String, default: "" },
    status: { type: Boolean, default: true },
    isReportedToHA: { type: Boolean, default: false },
    SROcomment:{type:String},
    commentsList:{type:Array, default: []},
    userUploadDocuments: {type:String},
    sroUploadDocuments: {type:String},
});

module.exports = mongoose.model("complaint", officerSchema, "complaint");
