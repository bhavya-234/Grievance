import React, { useEffect } from 'react'
import styles from '../../styles/components/PopupAlert.module.scss';
import { ImCross } from 'react-icons/im';
import { useAppSelector, useAppDispatch } from '../redux/hooks';
import { PopupAction } from '../redux/commonSlice';
import { useRouter } from 'next/router';
import { MdDone, MdOutlineDoneOutline } from 'react-icons/md';
import Image from 'next/image';
const PopupAlert = () => {
    const router = useRouter()
    const PopupMemory = useAppSelector((state) => state.common.PopupMemory);
    const dispatch = useAppDispatch()
    useEffect(() => {
        if (PopupMemory.enable) {
            setTimeout(() => {
                if (PopupMemory.redirectLocation && PopupMemory.redirectLocation != "") {
                    if (PopupMemory.redirectLocation === '/') {
                        setTimeout(() => { localStorage.clear(); }, 200);
                        setTimeout(() => {
                            router.push("/");
                        }, 0)
                    } else {
                        router.push(PopupMemory.redirectLocation);
                    }
                } dispatch(PopupAction({ ...PopupMemory, enable: false }))
            }, 5000);
        }
    }, [PopupMemory.enable])
    return (
        <div >
            {PopupMemory.enable &&
                <div className={styles.container}>
                    <div className={styles.Messagebox}>
                        <div className={styles.header}>
                            <div className={styles.letHeader} >
                                {PopupMemory.type ? <text className={styles.text}>Success!</text> : <text className={styles.text}>  Failed</text>}
                            </div>
                            {/* <div style={{cursor:'pointer'}}>
                                <ImCross onClick={() => ActionOnClick()} className={styles.crossButton} />
                            </div> */}
                        </div>
                        <div style={{ paddingLeft: '1rem', paddingRight: '1rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            {PopupMemory.type ?
                                <div style={{ padding: "15px" }}><Image alt='' width={200} height={200} className={styles.image} src="/grievance/images/ticksuccess.svg"></Image></div>
                                // <div style={{ backgroundColor: '#2CC746', borderRadius: '100px', width: '60px', height: '60px', display: 'flex', justifyContent: 'center', margin: '10px' }}>
                                //     <MdDone style={{ width: '30px', height: '30px', color: 'white', margin: '15px' }} />
                                // </div>
                                :
                                <div style={{ backgroundColor: 'red', borderRadius: '100px', width: '60px', height: '60px', display: 'flex', justifyContent: 'center', margin: '10px' }}>
                                    <ImCross style={{ width: '30px', height: '30px', color: 'white', margin: '15px' }} />
                                </div>
                            }
                            <div className={styles.message}>{PopupMemory.message}</div>
                        </div>
                    </div>
                </div>
            }
        </div>
    )
}

export default PopupAlert
