import React from 'react'

import pagenostyles from '../../styles/components/Pagination.module.scss'

const Pagination = ({ complaintlist, pageHandler }) => {
  let pagenumbers = []
  for (let i = 1; i < Math.ceil(complaintlist/ 10) + 1; i++) {
    pagenumbers.push(i)
  }


  return (
    <div className={pagenostyles.pagenumbers}>
    {
      pagenumbers.map((page, index) => {
        return (
          <div key={index} className={pagenostyles.pagenumber} onClick={() => pageHandler(page)}>
            {page}
          </div>
        )
      })
    }
    </div>
  )
}



export default Pagination