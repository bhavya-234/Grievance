// import React, { useState } from 'react'
// import styles from '../../styles/components/UploadDoc.module.scss';
// import { MdDownloadDone } from 'react-icons/md';

// interface PropsTypes {
//     label: string;
//     required: boolean;
//     onChange: any;
//     isUploadDone?: string;
// }

// const UploadDoc = ({ label, required, onChange, isUploadDone = '' }: PropsTypes) => {
//     return (
//         <div className={styles.rightBox}>
//             <text className={styles.checkBoxText}>File Browse</text>
//             <input className={styles.uploadInputBox}
//                 type='file'
//                 required={required}
//                 onChange={onChange}
//                 accept="image/png, image/jpeg, image/jpg"
//             />
//             <div className={styles.confirmUpload} style={{ backgroundColor: isUploadDone == 'true' ? 'green' : isUploadDone == 'false' ? 'red' : isUploadDone == 'process' ? 'yellow' : 'transperent' }}></div>
//             {
//                 isUploadDone == 'true' &&
//                 <MdDownloadDone style={{ height: '30px', width: '30px', color: 'green', }} />}
//         </div>
//     )
// }

// export default UploadDoc;

import React, { useState } from 'react'
import styles from '../../styles/components/UploadDoc.module.scss';
import { MdDownloadDone } from 'react-icons/md';

interface PropsTypes {
    label: string;
    required: boolean;
    onChange: any;
    isUploadDone?: string;
    accept?: string;
    onCancelUpload: any;
    uploadKey: string;
}
// var validate="^[a-zA-Z0-9,]*[.]{0,1}[a-zA-Z0-9,]*$";
// validate.includes(e.key) && e.preventDefault();
const UploadDoc = ({ label, required, onChange, onCancelUpload, uploadKey, isUploadDone = '', accept = "image/png, image/jpeg, image/jpg, application/pdf" }: PropsTypes) => {
    return (
        <div className={styles.rightBox}>
            {
                isUploadDone == "process" || isUploadDone == "false" || isUploadDone == "" ?

                    <div>
                        <div className={styles.checkBoxText}>{label}<text style={{ color: "red" }}>{required ? ' *' : null}</text></div>
                        <div style={{ display: "flex" }}>
                            <div style={{ width: '100%' }}>
                                <input className={styles.uploadInputBox}
                                    type='file'
                                    required={required}
                                    onChange={onChange}
                                    accept={accept}
                                />
                                <div className={styles.confirmUpload} style={{ backgroundColor: isUploadDone == 'false' ? 'red' : isUploadDone == 'process' ? 'yellow' : 'transperent' }}></div>
                            </div>
                        </div>
                    </div>
                    :
                    isUploadDone == 'true' &&
                    <div style={{ display: 'flex', alignItems: 'center', borderColor: 'black', borderWidth: '1px', borderRadius:'20px', backgroundColor: '#dddddd', width: '350px', justifyContent:'space-between' }}>
                        <div style={{ display: 'flex', alignItems: 'center', marginLeft:'1rem' }}>
                            <MdDownloadDone style={{ height: '30px', width: '30px', color: 'green', marginLeft: '2px' }} />
                            <div className={styles.checkBoxText} style={{ fontWeight: 600, fontSize: '14px', marginRight: '5px' }}>Document Uploaded</div>
                        </div>
                        <div onClick={() => onCancelUpload(uploadKey)} style={{ cursor: 'pointer', marginRight:'1rem' }}>X</div>
                    </div>
            }
        </div>

    )
}

export default UploadDoc;