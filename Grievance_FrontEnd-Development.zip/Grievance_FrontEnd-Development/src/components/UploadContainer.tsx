import React, { useState } from 'react'
import styles from '../../styles/components/uploadContainer.module.scss';
import { MdDownloadDone } from 'react-icons/md';

interface PropsTypes {
    label: string;
    required: boolean;
    onChange: any;
    isUploadDone?:string;
}

const UploadContainer = ({ label,  required, onChange,isUploadDone='' }: PropsTypes) => {
    return (
        <div className={styles.container}>
            <div className={styles.leftBox}>
                <div style={{ width: '80%' }}>
                    <text className={styles.checkBoxText}>{label}</text>
                    {required && <text className={styles.checkBoxText} style={{ color: 'red' }}>*</text>}
                </div>
            </div>
            <div className={styles.rightBox}>
                 <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}> 
                    <text className={styles.checkBoxText}>File Browse</text>
                    <div style={{width:'40%'}}>
                        <input className={styles.columnInputBox}
                            type='file'
                            required={required}
                            onChange={onChange}
                            accept="image/png, image/jpeg, image/jpg"
                        />
                        <div className={styles.confirmUpload} style={{backgroundColor: isUploadDone=='true'?'green':isUploadDone=='false'?'red':isUploadDone=='process'?'yellow':'transperent' }}></div>
                    </div>
                    {
                    isUploadDone=='true' &&
                    <MdDownloadDone style={{height:'30px',width:'30px',color:'green',}}/>}
                </div>
            </div>

            
         </div>
    )
}

export default UploadContainer;