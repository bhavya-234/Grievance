import React, { useEffect, useRef, useState } from 'react'
import { ImCross } from 'react-icons/im';
import TableInputText from './TableInputText';
import stylesPopup from '../../styles/components/ResetPassword.module.scss';
import { OfficerLogout, UsePasswordByOfficer } from '../axios';
import router from 'next/router';
import { useAppDispatch, useAppSelector } from '../../src/redux/hooks';
import Image from "next/image";
import { PopupAction } from '../redux/commonSlice';

interface PropsTypes {
	enable: boolean;
	setPopup: any;
	Popup: any;
}


const ResetPassword = ({ enable, setPopup, Popup }: PropsTypes) => {
	let LoginDetails = useAppSelector((state) => state.login.loginDetails);
	const [PswdDetails, setPswdDetails] = useState<any>({ currentPassword: "", newPassword: "", cnfPswrd: "" });
	const [eye, setEye] = useState<boolean>(false);
	const [text, settext] = useState('');
	const [eye1, setEye1] = useState<boolean>(false);
	const [eye2, setEye2] = useState<boolean>(false);
	const dispatch = useAppDispatch();

	const changeValue = async (e: any) => {
		let addValue = e.target.value;
		let addName = e.target.name;
		let tempDetails = { ...PswdDetails }
		if (addName == "currentPassword" || addName == "newPassword" || addName == "cnfPswrd") {
			addValue = addValue.replace(/\s/g, "")

		}
		setPswdDetails({ ...tempDetails, [addName]: addValue })

	}

	const passcodeRules = ['* Password should contain atleast 8 characters.', '* Atleast one uppercase letter.', '* Atleast one lowercase letter.', '* Atleast one digit.', 'Example: tEst1234.'];

	const validateForm = (loginPasscode) => {

		if (!(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/.test(loginPasscode))) {
			return false;
		}
		return true;
	}
	const renderHints = () => {
		return <div className={stylesPopup.ruleBox}>{passcodeRules.map(rule => {
			return <div key={rule}>{rule}</div>
		})}</div>
	}
	const validate = () => {
		let flag = true, msg = '';
		if (PswdDetails.currentPassword === "") {
			flag = false;
			msg = 'Please enter old password'
		}
		else if (!validateForm(PswdDetails.newPassword)) {
			flag = false;
			msg = 'Please enter a valid and strong password'
		}
		else if (PswdDetails.newPassword !== PswdDetails.cnfPswrd) {
			flag = false;
			msg = 'Password does not match'
		}
		else if (PswdDetails.newPassword == PswdDetails.currentPassword == PswdDetails.cnfPswrd) {
			flag = false;
			msg = ' New Password should not be same as old password.'
		}
		msg && ShowAlert(false, msg, '')
		return flag;
	}
	const ShowAlert = (type, message, redirect) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirect: redirect })); }


	const onSubmit = async (e: any) => {
		e.preventDefault();
		setPswdDetails({ currentPassword: "", newPassword: "", cnfPswrd: "" });
		setPopup({ ...Popup, enable: false });
		if (validate()) {
			var setPswrdDetails = {
				"loginEmail": LoginDetails.loginEmail,
				"currentPassword": PswdDetails.currentPassword,
				"newPassword": PswdDetails.newPassword
			}
			await UsePasswordByOfficer(setPswrdDetails)
				.then((res: any) => {
					if (res.status === true) {
						setPswdDetails({ currentPassword: "", newPassword: "", cnfPswrd: "" });
						ShowAlert(true, "Please Login again with new Password", '')
						setTimeout(() => { localStorage.clear(); }, 200);
						setTimeout(() => {
							router.push("/");
						}, 0);
					}
					else
						ShowAlert(false, res.message, '');
				}).catch((e) => {
					console.log("error :::::::: ", e);
					ShowAlert(false, e.message, '');
				})
		}
	}
	const reset = () => {
		setPopup({ ...Popup, enable: false });
		setPswdDetails({ currentPassword: "", newPassword: "", cnfPswrd: "" });
	}
	const textInput = useRef(null);
	function handleClick() {
		textInput.current.focus();
	}
	return (
		<div>
			{enable &&
				<form className={stylesPopup.container} onSubmit={onSubmit} autoComplete="off">
					<div className={stylesPopup.Messagebox}>
						<div className={stylesPopup.header}>
							<div className={stylesPopup.letHeader} >
								<h5>Reset Password</h5>
							</div>
							<div>
								<ImCross onClick={reset} className={stylesPopup.crossButton} />
							</div>
						</div>
						<div style={{ marginTop: '20px', marginRight: '4%' }}>
							<div>
								<div style={{ display: "flex", marginTop: '10px' }}>
									<h6>Old Password :</h6>

									<div style={{ width: "200px", marginLeft: '16%', position: 'relative' }}>
										<TableInputText type={eye ? 'text' : 'password'} placeholder={'OLD PASSWORD'} required={true} value={PswdDetails.currentPassword} onChange={changeValue} name={'currentPassword'} />
										<div style={{ top: "4px", right: '8px', position: 'absolute' }} onClick={() => { setEye(!eye) }}>
											<Image height={14} width={20} src={eye ? "/grievance/images/eye.svg" : "/grievance/images/eye_hide.svg"} />
										</div>
									</div>
								</div>
							</div>
							<div >
								<div style={{ display: "flex", marginTop: '10px' }}>
									<h6>New Password : </h6>

									<div style={{ width: "200px", marginLeft: '14%', position: 'relative' }}>
										<TableInputText type={eye1 ? 'text' : 'password'} placeholder={'NEW PASSWORD'} required={true} value={PswdDetails.newPassword} onChange={changeValue} name={'newPassword'} />
										<div style={{ top: "4px", right: '8px', position: 'absolute' }} onClick={() => { setEye1(!eye1) }}>
											<Image height={14} width={20} src={eye1 ? "/grievance/images/eye.svg" : "/grievance/images/eye_hide.svg"} />
										</div>
									</div>
								</div>
								{/* <text style={{ color: 'red' }}>{( PswdDetails.currentPassword!==PswdDetails.newPassword)  ? null : "New Password should not be matched with Old Password"}</text> */}

								{renderHints()}

							</div>
							<div>
								<div style={{ display: "flex", marginTop: '10px' }}>
									<h6>Confirm Password :</h6>

									<div style={{ width: "200px", marginLeft: '31px', position: 'relative' }}>
										<TableInputText type={eye2 ? 'text' : 'password'} placeholder={'CONFIRM PASSWORD'} required={true} value={PswdDetails.cnfPswrd} onChange={changeValue} name={'cnfPswrd'} />
										<div style={{ top: "4px", right: '8px', position: 'absolute' }} onClick={() => { setEye2(!eye2) }}>
											<Image height={14} width={20} src={eye2 ? "/grievance/images/eye.svg" : "/grievance/images/eye_hide.svg"} />
										</div>
									</div>
								</div>
								<text style={{ color: 'red', paddingLeft: "45%" }}>{(PswdDetails.newPassword !== PswdDetails.cnfPswrd && (PswdDetails.newPassword == "") == (PswdDetails.cnfPswrd == "")) ? "Password not matched" : ""}</text>

							</div>
							<div style={{ marginTop: '33px', display: 'center' }}>
								<button className={stylesPopup.button}  >SUBMIT</button>
							</div>
						</div>
					</div>
				</form>
			}
		</div>
	)
}

export default ResetPassword