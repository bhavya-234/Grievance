import React from 'react';
import Image from "next/image";
import styles from '../../styles/components/Footer.module.scss';

const Footer = () => {
  return (
    <footer>
      <div className={styles.footerContainer}>
        <text className={styles.footerText}>Copyright © All rights reserved with Registration & Stamps Department, Government of Andhra Pradesh.</text>
      </div>
    </footer>
  )
}

export default Footer