import { Form } from 'react-bootstrap';
import styles from '../../styles/components/Table.module.scss';
interface PropsTypes {
  type: string,
  required?: boolean;
  value: string;
  onChange: any;
  name: string;
  disabled?: boolean;
  label: string;
  errorMessage: string;
  splChar?: boolean;
  dot?: boolean;
  emailSplChar?: boolean;
  maxLength?: number;
  allowNeg?: boolean;
  allowFSlash?: boolean;
}
const TableInputTextData = ({ type, disabled = false, required = false, value, name, onChange, label, errorMessage, splChar = true, dot = true,
  emailSplChar = false, maxLength, allowNeg = false, allowFSlash = true  }: PropsTypes) => {
  const blockInvalidChar = e => {
    if(type === "text")
    {
      if (!splChar) { ['/', '=', ',', ']', '[', "'", ';', ':', '<', '>', '{', '}', '?', '"', '!', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '-'].includes(e.key) && e.preventDefault(); }
      if (dot == false) { ['.'].includes(e.key) && e.preventDefault(); }
    }
    else if(type === "email")
    {
      if (!emailSplChar) { ['/', '=', ',', ']', '[', "'", ';', ':', '<', '>', '{', '}', '?', '"', '!', '#', '$', '%', '^', '&', '*', '(', ')'].includes(e.key) && e.preventDefault(); }
    }
    else if (type == "number") {
      if (!splChar) { [ '=', ',', ']', '[', "'", ';', ':', '<', '>', '{', '}', '?', '"', '!', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+'].includes(e.key) && e.preventDefault(); }
      // if (e.key !== 'Backspace') {
      //   const regex = /[0-9/-]/;
      //   if (!regex.test(e.key)) { e.preventDefault() }
      // }
      if (!allowFSlash) {
        ['/'].includes(e.key) && e.preventDefault();
      }
      if (!allowNeg) {
        ['-'].includes(e.key) && e.preventDefault();
      }
      if (maxLength && String(e.target.value).length >= maxLength && e.key != 'Backspace') { e.preventDefault(); }
      if (dot == false) { ['.'].includes(e.key) && e.preventDefault(); }
    }
  }
  return (
    <div>
      <Form.Floating>
        <Form.Control
          className={styles.columnInputBox1}
          // style={{ textTransform: (type != 'email' && type != 'password') ? 'uppercase' : 'none' }}
          name={name}
          type={type}
          disabled={disabled}
          placeholder={label}
          required={required}
          value={value}
          onChange={onChange}
          onKeyDown={blockInvalidChar}
          onWheel={event => event.currentTarget.blur()}
        />
        <label htmlFor="floatingInputCustom">
          {label}
        </label>
      </Form.Floating>
      <Form.Text className="text-danger">{errorMessage}</Form.Text>
    </div>
  );
}
export default TableInputTextData;
