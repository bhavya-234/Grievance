import React, { useState } from 'react'
import styles from '../../styles/components/uploadContainer.module.scss';
import { MdDownloadDone } from 'react-icons/md';

interface PropsTypes {
    label: string;
    required: boolean;
    onChange: any,
    isUploadDone?: string;
}

const SelectUploadContainer = ({ label, required, onChange, isUploadDone = '' }: PropsTypes) => {
    const [isChecked, setIsChecked] = useState(false)
    return (
        <div className={styles.container}>
            <div className={styles.leftBox}>
                <div style={{ width: '20%' }}>
                    <input
                        required={false}
                        className={styles.checkBox}
                        type="checkbox"
                        value=""
                        checked={isChecked}
                        onChange={() => setIsChecked(!isChecked)}
                    />
                </div>
                <div style={{ width: '80%' }}>
                    <text className={styles.checkBoxText}>{label}</text>
                    {required && <text className={styles.checkBoxText} style={{ color: 'red' }}>*</text>}
                </div>

            </div>
            {isChecked &&
                <div className={styles.rightBox2}>
                    <text className={styles.checkBoxText}>File Browse</text>
                    <div style={{width:'40%'}}>
                        <input className={styles.columnInputBox}
                            type='file'
                            required={required}
                            onChange={onChange}
                        />
                        <div className={styles.confirmUpload} style={{ backgroundColor: isUploadDone == 'true' ? 'green' : isUploadDone == 'false' ? 'red' : isUploadDone == 'process' ? 'yellow' : 'transperent' }}></div>
                    </div>
                    {
                isUploadDone=='true' &&
                <MdDownloadDone style={{height:'30px',width:'30px',color:'green',}}/>}
                </div>}
                
        </div>
    )
}

export default SelectUploadContainer;