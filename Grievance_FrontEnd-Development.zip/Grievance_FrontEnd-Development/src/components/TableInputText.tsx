import styles from '../../styles/components/Table.module.scss';

interface PropsTypes {
  type: string,
  placeholder: string;
  required: boolean;
  value: string;
  onChange: any;
  name: string;
  disabled?: boolean;
}

const TableInputText = ({ type, disabled = false, placeholder, required = false, value, name, onChange }: PropsTypes) => {

  const blockInvalidChar = e => {
    if (type == "number") {
      ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault();
    }
  }

  return (
    <div >
      <input className={styles.columnInputBox}
        // style={{ textTransform: (type != 'email' && type != 'password') ? 'uppercase' : 'none' }}
        name={name}
        type={type}
        disabled={disabled}
        placeholder={placeholder}
        required={required}
        value={value}
        onChange={onChange}
        onKeyDown={blockInvalidChar}
        onWheel={event => event.currentTarget.blur()}
      />
    </div>
  );
}

export default TableInputText;
