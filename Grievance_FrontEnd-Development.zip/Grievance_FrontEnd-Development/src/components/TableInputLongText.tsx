import styles from '../../styles/components/Table.module.scss';

interface PropsTypes {
  placeholder: string;
  required: boolean;
  value: string;
  onChange: any;
  name: string,
}

const TableInputLongText = ({ name, placeholder, required = false, value, onChange }: PropsTypes) => {

  return (
    <div >
      <textarea rows={5} className={styles.columnInputBox}
        style={{ textTransform: 'uppercase' }}
        placeholder={placeholder}
        required={required}
        value={value}
        name={name}
        onChange={onChange}
      />
    </div>
  );
}

export default TableInputLongText;
