import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/router';
import styles from '../../styles/pages/Mainpage.module.scss'
import Image from "next/image";
import Dropdown from 'react-bootstrap/Dropdown';
import { useAppSelector, useAppDispatch } from '../redux/hooks';
import { ChangeSelectedPage } from '../redux/commonSlice';
import { saveLoginDetails } from '../redux/loginSlice';

const MyNavbar = () => {
    const dispatch = useAppDispatch()
    let initialLoginDetails = useAppSelector((state) => state.login.loginDetails);
    const [LoginDetails, setLoginDetails] = useState(initialLoginDetails);
    let SelectedPage = useAppSelector((state) => state.common.SelectedPage);

    const router = useRouter();

    const redirectToPage = (location: string, query: {}) => {
        if (location != "") {
            dispatch(ChangeSelectedPage(location));
            router.push({
                pathname: location,
                query: query,
            })
        }
    }
    // useEffect(() => {
    //     let data: any = localStorage.getItem("loginDetails");
    //     data = JSON.parse(data);
    //     if (data && data.token) {
    //         setLoginDetails(data)
    //     }
    //     else {
    //         router.push("/Login");
    //     }
    // }, [])

    return (
             <div className={styles.Navbar} style={{ justifyContent: 'space-between' }}>
                <div style={{ display: 'flex' }}>
                    <div className={styles.linkshidden} style={{ cursor: 'pointer'}} onClick={() => { redirectToPage("/Mainpage", {}) }} > <Image alt='' width={20} height={20} className={styles.image} src="/grievance/images/Vector.svg"></Image></div>
                    <div className={styles.linkshidden} style={{ cursor: 'pointer', backgroundColor: SelectedPage == "/ComplaintLodging" ? '#30395B' : null }} onClick={() => { redirectToPage("/ComplaintLodging", {portal:"E-CHITS"}&&{}) }}> Lodge Grievance </div>
                    <div className={styles.linkshidden} style={{ cursor: 'pointer', backgroundColor: SelectedPage == "/GrievanceUserStatus" ? '#30395B' : null }} onClick={() => { redirectToPage("/GrievanceUserStatus", {}) }}> View Status </div>
                    <a target='_blank' className={styles.linkshidden} style={{ textDecoration:null ,cursor: 'pointer', backgroundColor:SelectedPage == "/pdf" ? '#30395B' : null }} href='/grievance/pdf/user_manual.pdf' > User Manual </a>
                    
                </div>
                <div className={styles.button} style={{ cursor: 'pointer', backgroundColor: SelectedPage == "/Login" ? '#30395B' : null }} onClick={() => { redirectToPage("/Login", {}) }} > Department Login </div>
            </div>
    
    )
}

export default MyNavbar;