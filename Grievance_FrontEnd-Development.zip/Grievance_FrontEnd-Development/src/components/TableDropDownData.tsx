import { Form } from 'react-bootstrap';
import styles from '../../styles/components/Table.module.scss';
import TableInputTextData from './TableInputTextData';
interface PropsTypes {
    required: boolean;
    onChange: any;
    options: any;
    name: string;
    value?: string;
    keyName: string;
    disabled?: boolean;
    // label: string;
    errorMessage: string;
    keyValue: string;
}
const TableDropDownData = ({ required = false, onChange, options = [], keyName, keyValue, name, value = "", disabled = false,  errorMessage }: PropsTypes) => {
    const FindValue = (value: any) => {
        let data = options?.find(x => x.value == value);
        return data?.label;
    }
    return (
        <div>
            <div> 
                {!disabled ?
                    <Form.Select className={styles.columnDropDownBox1} name={name} value={FindValue(value)} onChange={onChange} required={required} style={{ fontFamily: 'Montserrat' }}>
                        <option disabled selected key='' value=''>SELECT . . .</option>
                        {options.map((singleOption: any, index: any) => {
                            return (
                                <option key={index} value={singleOption[keyValue]}>{singleOption[keyName]}</option>
                            );
                        })}
                    </Form.Select>
                    :
                    <TableInputTextData required={false} type='text' disabled={true} name={name} value={value} onChange={onChange} label={'label'} errorMessage={'errorMessage'}   />
                }
                <Form.Label for="my-dropdown">
                    {/* {label} */}
                    </Form.Label>
            </div>
            <Form.Text className="text-danger">{errorMessage}</Form.Text>
        </div>
    );
}
export default TableDropDownData;