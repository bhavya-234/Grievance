import { useState } from 'react';
import styles from '../../styles/components/Table.module.scss';

interface PropsTypes {
  value: string;
}

const TableTextAera = ({ value }: PropsTypes) => {
  const [ReadMore, setReadMore] = useState(false)

  return (
    <div style={{ width: '100%'}} >
      {ReadMore ?
        <div style={{wordWrap:'break-word',overflowWrap:'break-word',width:'100%'}}>
          <textarea
            rows={(value.match(/\n/g) || '').length + 5}
            disabled={true} style={{ width: '100%', borderColor: 'transparent', borderRadius: '0px', backgroundColor: 'transparent',color:'black',fontWeight:'500' }} placeholder={'Enter Max 1000 Characters'}
            value={value} />
          <div style={{ cursor: 'pointer', fontWeight: 'bold' }} onClick={() => setReadMore(false)}>...ReadLess</div>
        </div>
        :
        <div style={{  overflow:'hidden' }}>
          <text className={styles.valueText} style={{overflow:'hidden'}}>{value && value.substring(0,100)}</text>
          {value && value.length > 110 ? <div style={{ cursor: 'pointer', fontWeight: 'bold' }} onClick={() => setReadMore(true)}>...ReadMore</div> : null}

        </div>
      }</div>
  );
}

export default TableTextAera;
