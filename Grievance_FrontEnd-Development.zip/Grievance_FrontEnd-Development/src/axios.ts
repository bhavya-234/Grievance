import axios from "axios";
import instance from "./redux/api";

const mess=(e)=>(e && e.response && e.response.data&&e.response.data.message ? e.response.data.message : 'Something went wrong');
//const url = process.env.API_URL+"/api";
export const useUploadDoc = async (data: any, formData: any) => {
  return await instance.post("/complaint/fileUpload",formData )
  .then((res) => {return res.data;})
  .catch((e) => {return {status:false,message:mess(e)}})
  }
  export const verifyotp = async (id:any,otp:any) => {
    let data={"id":id, "otp":otp};
    return await instance.post("/complaint/verifySMS",data)
    .then((res) => {return res.data;})
    .catch((e) => {return {status:false,message:mess(e)}})
    }
    export const sendotp = async (data:any) => {
      return await instance.post("/complaint/sendSMS",data)
      .then((res) => {return res.data;})
      .catch((e) => {return {status:false,message:mess(e)}})
      }
      export const resendotp = async (id:any) => {
        let data={"id":id}
        return await instance.post("/complaint/resendSMS",data)
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}})
        }
  export const useUploadDocbyuser = async (data: any, formData: any) => {
  return await instance.post("/complaint/fileUpload/user",formData )
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}})
        }       
export const useSaveUser = async (UserDetails: any) => {
    return await axios.post( "/users", UserDetails)
        .then((res) => {return 'User Data saved Successfully';})
        .catch((e) => {return {status:false,message:mess(e)}});
}
export const GetStatusCount = async (loginId: any) => {
    return await instance.get( "/complaint/overview/"+loginId)
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}});
}
export const useOfficerLogin = async (data: any) => {
    return await instance.post( "/officer/login", data)
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:e.message}})
}
export const OfficerLogout = async () => {
  return await instance.get( "/officer/logout")
      .then((res) => {return res.data;})
      .catch((e) => {return {status:false,message:mess(e)}})
}

export const UsePasswordByOfficer = async (data: any) => {
  return await instance.post( "/officer/resetPassword", data)
      .then((res) => {return res.data;})
      .catch((e) => {console.log("Error:" + e.message);})
}
export const useSingup = async (data: any) => {
    return await instance.post( "/signup", data)
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}})
}
export const useUserLogin = async (data: any) => {
    return await instance.post( "/login", data)
        .then((res) => {return res.data;})
        .catch((e) =>{return {status:false,message:mess(e)}})
}
export const useSaveComplaintDetails = async (data: any) => {
    return await instance.post( "/complaint/create",data)
      .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}});
}
export const usegetComplaintsByNo = async (UserAccessDetails: any) => {
  return await instance.get( "/complaint/getComplaintByNumber/"+UserAccessDetails)
  .then((res) => {return {...res.data, status: true};})
        .catch((e) => {return {status: false, message: mess(e)}});
  }
  export const usergetComplaintsByNo = async (UserAccessDetails: any) => {
  return await instance.get( "/complaint/user/"+UserAccessDetails) 
  .then((res) => {return {...res.data, status: true};})
        .catch((e) => {return {status: false, message: mess(e)}});
  }
export const UseGetcomplaintList = async (status:string,page:string,loginId:string,search:string) => {  
    console.log("logingId :"+loginId) 
    return await instance.get( "/complaint/getComplaints/"+page+"/"+status+"/"+loginId+"?"+`${search ? `&search=${search}`: ''}`) 
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}});
} 
export const UseGetcomplaintListDr = async (status:string,location:any,page:string, search: string,loginId:string) => {   
    return await instance.get( "/complaint/getComplaints/"+page+"/"+status+"/"+loginId+"?"+location+`${search ? `&search=${search}`: ''}`) 
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}});
}
export const Updatestatus = async (data: any) => {
    return await instance.put( "/complaint/updateComplaint/"+data.complaintNo, data)
    .then((res) => {return res.data;})
    .catch((e) => {return {status:false,message:mess(e)}})
}
    export const Updatestatusbyuser = async (data: any) => {
    return await instance.put( "/complaint/user/updateComplaint/"+data.complaintNo, data)
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}})
}
export const UseHigherAppeal = async (data: any) => {
    return await instance.post( "/complaint/report/user/"+data)
    .then((res) => {return res.data;})
    .catch((e) => {return {status:false,message:mess(e)}})
}
export const HigherAppealofficer = async (data: any) => {
    return await instance.post( "/complaint/report/"+data)
        .then((res) => {return res.data;})
        .catch((e) => {return {status:false,message:mess(e)}})
}
export const useGetDistrict = async ( ) => {
  return await instance.get( "/masterData/categories?state=AP")
  .then((res) => {return res.data;})
  .catch((e) => {{ console.log("Error:" + e.message); }});
}
export const useGetMandal = async (district: string) => {
  return await instance.get( "/masterData/categories?state=AP&district=" + district)
  .then((res) => { return res.data; })
  .catch((e) => { return {status:false,message:mess(e)} });
}
export const useGetSRO = async (district_mandal: string) => {
    return await instance.get( "/masterData/categories?state=AP&district=" + district_mandal)
  .then((res) => { return res.data; })
  .catch((e) => { return {status:false, message:mess(e)}})
}
