import { createSlice, PayloadAction } from "@reduxjs/toolkit"
interface TypeOFinitialState {
    loginDetails:any
}

const initialState: TypeOFinitialState = {
    loginDetails:{
        loginId: '',
        loginEmail: '',
        loginName: '',
        lastLogin:'',
        token: '',
        loginType: '',
        complaintNo:'',
        role:'',
        sro:''
    },
}
export const loginSlice = createSlice({
    name: "login",
    initialState,
    reducers: {
        saveLoginDetails: (state, action: PayloadAction<any>) => {
            state.loginDetails = action.payload;
        },
        saveGravienceID:(state,action: PayloadAction<string>)=>{
            state.loginDetails= {...state.loginDetails,complaintNo:action.payload}
        }
    }
})

export const { saveLoginDetails,saveGravienceID } = loginSlice.actions;
export default loginSlice.reducer;