import {createSlice, PayloadAction} from "@reduxjs/toolkit"

interface TypeOFinitialState {
    value: string;
    PopupMemory:any
    Loading:any
    SelectedPage:any
  }

const initialState:TypeOFinitialState = {
    value:"Hello World",
    PopupMemory:{
        enable: false,
        type: true,
        message: "",
        redirectLocation:""
      },
      Loading:{
        enable: false
      },
      SelectedPage:"/Mainpage"
}
export const commonSlice = createSlice({
    name:"common",
    initialState,
    reducers:{
        ChangeTo:(state,action:PayloadAction<any>)=>{
            state.value = action.payload;
        },
        PopupAction:(state,action:PayloadAction<any>)=>{
            state.PopupMemory = action.payload;
        },
        LoadingAction:(state,action:PayloadAction<any>)=>{
            state.Loading=action.payload;
        },
        ChangeSelectedPage:(state,action:PayloadAction<any>)=>{
            state.SelectedPage=action.payload;
        },
    }
})

export const {ChangeTo, PopupAction,LoadingAction, ChangeSelectedPage} = commonSlice.actions; 
export default commonSlice.reducer;