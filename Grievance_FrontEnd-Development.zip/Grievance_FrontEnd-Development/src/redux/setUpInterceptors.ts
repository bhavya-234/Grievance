import instance from './api';

const SetUp = () => {
    instance.interceptors.request.use(
        function(config) {
          const data = localStorage.getItem("loginDetails");
          let parsedData;
          try{
            parsedData = JSON.parse(data);
            if (parsedData && parsedData.token && parsedData.token) {
                config.headers["Authorization"] = 'Bearer ' + parsedData.token;
              }
          } catch{
            parsedData= false;
          }
          return config;
        },
        function(error) {
          return Promise.reject(error);
        }
      );
      
      instance.interceptors.response.use(async (response) => {
          return response;
       }, async(error)=>{
        const originalConfig = error.config;
        if (error && error.response && error.response.status === 401 && !originalConfig._retry) {
         originalConfig._retry = true;
         try{
            const g = localStorage.getItem("loginDetails");
            let parsedData; 
            try{
                parsedData = JSON.parse(g);
               if(parsedData && parsedData.token && parsedData.token.refreshTokenUrl){
                    const rs = await instance.get('/token');
                    if(rs.data.data.token){
                        parsedData.token.token = rs.data.data.token;
                        localStorage.setItem("loginDetails",JSON.stringify(parsedData));
                        return instance(originalConfig)
                    }
                    else{
                        localStorage.clear();
                        setTimeout(() => {
                            window.location.href = "/"
                        }, 0) 
                    }
                }
            } catch(_error1){
                localStorage.clear();
                setTimeout(() => {
                    window.location.href = "/"
                }, 0)
                return Promise.reject(_error1);
            }
            // const rs = await instance.get(`/`)
            // const rs = await instance.get(`/token/${auth.getUserDetails().loginId}`);
        //     if(get(rs, 'data.data.token.token', '')){
        //         localStorage.setItem("access_token", get(rs, 'data.data.token.token', ''))
        //         return instance(originalConfig);
        //       }
        //       else{
        //         localStorage.clear();
        // setTimeout(() => {
        //     window.location.href = "/"
        // }, 0)
        //       }
         }catch (_error) {
            localStorage.clear();
        setTimeout(() => {
            window.location.href = "/"
        }, 0)
        return Promise.reject(_error);
         }
       }
       else if (error.response.status === 401){
        localStorage.clear();
        setTimeout(() => {
            window.location.href = "/"
        }, 0)
       }
       return Promise.reject(error);
    });
} 
export default SetUp;