// // const ContentSecurityPolicy = `
// //   default-src 'self' 'unsafe-inline' https://117.254.87.83:4000 https://117.254.87.83:3000;
// //   script-src 'self' 'unsafe-inline';
// //   child-src https://117.254.87.83:4000 https://117.254.87.83:3000;
// //   style-src 'self' 'unsafe-inline' https://117.254.87.83:4000 https://117.254.87.83:3000 https://fonts.googleapis.com https://www.gstatic.com;
// //   font-src 'self' 'unsafe-inline' https://fonts.gstatic.com;
// //   img-src * 'self' data: https:;
// // `
/** @type {import('next').NextConfig} */
const securityHeaders = [
  {key: 'X-Frame-Options',value: 'SAMEORIGIN'},
  // {key: 'X-XSS-Protection',value: '1; mode=block'},
  // {key: 'X-Content-Type-Options',value: 'nosniff'},
  // {key: 'Content-Security-Policy',value: ContentSecurityPolicy.replace(/\s{2,}/g, ' ').trim()},
  // {key: 'Strict-Transport-Security',value: 'max-age=63072000; includeSubDomains; preload'}
]
const nextConfig = {
  async headers() {
    return [
      {
        source: '/:path*',
        headers: securityHeaders,
      },
    ]
  },
  reactStrictMode: false,
  swcMinify: true,
  poweredByHeader: false,
  env: {
    // IP_ADDRESS_WITH_PORT: 'http://117.254.87.83:4002',
    // API_URL: 'http://117.254.87.83:4002/grievanceService',
    // PORT: 4002
    IP_ADDRESS_WITH_PORT:process.env.IP_ADDRESS_WITH_PORT,
    API_URL:process.env.API_URL,
    PORT:process.env.PORT,
  },
  basePath:"/grievance"
}

module.exports = nextConfig
