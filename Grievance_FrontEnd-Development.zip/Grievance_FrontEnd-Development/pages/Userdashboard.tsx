
import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import dastyles from '../styles/pages/Userdashboard.module.scss';
import { useAppSelector } from '../src/redux/hooks';

const Userdashboard = () => {
const router=useRouter()

let LoginDetails = useAppSelector((state)=> state.login.loginDetails);
        useEffect(() => { !LoginDetails.token && router.push("/"); }, [router,LoginDetails])
    
        const ShiftToLocation = (location: string, query: {}) => {
            router.push({
                pathname: location,
                
            })
        }
  return (

    <div className={dastyles.container}>
     
      <div className={dastyles.Navbar}>
                <text className={dastyles.NavbarText}> Welcome : {LoginDetails.loginName} ({LoginDetails.loginType && LoginDetails.loginType.toUpperCase()})</text>
                {/* <div style={{ cursor: 'pointer' }} onClick={() => { ShiftToLocation("/", {}) }} ><text className={dastyles.NavbarText}> Logout </text></div> */}
            </div>
           <div className={dastyles.dashboardcontainer}>
            <text className={dastyles.titletext}>User Dashboard</text>
            <div className={dastyles.dashboardbuttoncontainer}>
            <div className={dastyles.buttoncontainer}style={{ cursor: 'pointer' }} onClick={() => { ShiftToLocation("/", {}) }} ><text className={dastyles.buttons}> Existing User </text></div>
            <div className={dastyles.buttoncontainer}style={{ cursor: 'pointer' }} onClick={() => { ShiftToLocation("/ComplaintLodging", {}) }} ><text className={dastyles.buttons}> New Registration </text></div>
        </div>
    </div>
</div>
  )
}

export default Userdashboard