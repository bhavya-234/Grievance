import React, { useEffect, useState } from 'react';
import styles from '../styles/pages/GrievanceStatus.module.scss';
import TableInputText from '../src/components/TableInputText';
import TableText from '../src/components/TableText';

import { useAppDispatch } from '../src/redux/hooks';
import { useRouter } from 'next/router';
import { Updatestatusbyuser, usergetComplaintsByNo, useUploadDocbyuser, UseHigherAppeal } from '../src/axios';
import { LoadingAction, PopupAction } from '../src/redux/commonSlice';

import Image from "next/image";
import Moment from 'moment';
import MyNavbar from '../src/components/MyNavbar';
import UploadDoc from '../src/components/UploadDoc';
import { Header } from '../src/components/Header';
import TableTextAera from '../src/components/TableTextAera';

const GrievanceStatus = () => {
    const dispatch = useAppDispatch()
    const router = useRouter()
    const [ComplaintStatus, setComplaintStatus] = useState<any>({});
    const [InputgravianceId, setInputgravianceId] = useState<string>("");
    const [AllowHigherAppeal, setAllowHigherAppeal] = useState(false);
    const [TempUploadDetails, setTempUploadDetails] = useState<any>([]);


    const ShowAlert = (type, message, redirectLocation) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirectLocation })); }
    const Loading = (value: boolean) => { dispatch(LoadingAction({ enable: value })); }

    const getComplaintsBySearch = async (complaintNo: any) => {

        Loading(true);
        let result = await usergetComplaintsByNo(complaintNo);
        console.log(result)
        Loading(false);
        if (result.status) {
            if (result.data[0]) {
                setComplaintStatus(result.data[0]);
            }
            else {
                ShowAlert(false, "Grievance Id Did Not Found.", "")
            }
        }
    }

    useEffect(() => {
        localStorage.clear();
    }, [])


    const HigherAppeal = async () => {
        if (window.confirm("Are You Sure, You Wish to Apply For Higher Authority?")) {
            Loading(true);
            let result = await UseHigherAppeal(ComplaintStatus.complaintNo);
            Loading(false);
            if (result.status) {
                ShowAlert(true, 'Grievance has been appealed to higher authority', "");
                getComplaintsBySearch(InputgravianceId);

            } else {
                ShowAlert(false, 'Update failed', "");
            }
        }
    }
    const onChange = (e: any) => {
        let addName = e.target.name
        let addValue = e.target.value;
        if (addName == "comment") {
            if (addValue == " ") { addValue = ""; }
            if (addValue.length > 1000) {
                addValue = addValue.substring(0, 1000);
            }
        }
        setComplaintStatus({ ...ComplaintStatus, [addName]: addValue })

    }

    const OnSubmitUpdate = async (e: any) => {
        e.preventDefault();
        UseHigherAppeal(ComplaintStatus.complaintNo);
        await updatestatusinfo()
    };

    const updatestatusinfo = async () => {
        let data = {
            complaintStatus: "Appealed to Higher Authority",
            complaintNo: ComplaintStatus.complaintNo,
            isReportedToHA: true,
            commentsList: [{
                comment: ComplaintStatus.comment,
                name: "USER",
                role: "USER",
                uploadFile: { documents: TempUploadDetails }
            }]
        };

        Loading(true);
        let result = await Updatestatusbyuser(data);
        Loading(false);
        if (result.status) {
            ShowAlert(true, 'Appealed to Higher Authority Successfully', "");
            getComplaintsBySearch(ComplaintStatus.complaintNo);
        } else {
            ShowAlert(false, 'Update failed', "");
        }
    }
    const OnFileSelect = async (event: any, docName: string, uploadName: string) => {
        if (event.target.files.length) {
            if (event.target.files[0].size > 5245329) {
                ShowAlert(false, "File size should not be more than 5MB.", "");
                event.target.value = "";
            }
            else {
                const file = event.target.files[0];
                console.log(file)
                let fileNamesSplit = file.name.split('.');
                let validFileExtensions = ["jpg", "jpeg", "bmp", "png", "pdf"];
                if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
                    // throw Error("Invalid File");
                    ShowAlert(false, "Irrelevant file type. Only image/pdf can be uploaded.", "");
                    event.target.value = "";
                }
                else {
                    setComplaintStatus({ ...ComplaintStatus, [uploadName]: "process" });
                    const formData = new FormData();
                    formData.append('image', event.target.files[0]);
                    let data: any = {
                        docName: docName,
                    }
                    await ForUploadDoc(data, formData, uploadName);
                }
            }
        }

    }

    const ForUploadDoc = async (data: any, formData: any, uploadName: string) => {
        Loading(true);
        let result = await useUploadDocbyuser(data, formData);
        Loading(false);
        if (result.status) {
            // let documents = ComplaintStatus.documents;
            let documents = [];
            documents.push(result.data);
            setTempUploadDetails(documents);
            setComplaintStatus({ ...ComplaintStatus, [uploadName]: "true" });
        }
        else {
            setComplaintStatus({ ...ComplaintStatus, [uploadName]: "false" });
        }
    }

    const OnSubmit = async (e: any) => {
        e.preventDefault();
        let count = 0
        for (var i = 0, len = InputgravianceId.length; i < len; i++) {
            if (InputgravianceId[i] == ' ')
                count++;
        }

        if (InputgravianceId == "" || count > 0) {
            ShowAlert(false, "Please Enter Grievance Id to Search", "")
        }
        else {
            await getComplaintsBySearch(InputgravianceId);

        }
    };

    const onChangeForSearch = (e: any) => {
        setInputgravianceId(e.target.value)

    };

    const onCancelUpload = (uploadKey) => {
        setComplaintStatus({ ...ComplaintStatus, [uploadKey]: "", documents: [] });
    }

    const DisplayTable = (key: any, value: any, color) => {
        return (
            <div className={styles.DisplayTableContainer} style={{ display: 'flex', backgroundColor: color, marginBottom: '2px' }}>
                <div className={styles.KeyContainer} >
                    <text className={styles.keyText}>{key}</text>
                </div>:
                <div className={styles.ValueContainer}>
                    {key == "Description" ?
                        <TableTextAera value={value} />
                        :
                        <text style={{ color: key == "Status" ? StatusColor(value) : null, fontWeight: key == "Status" ? "bold" : null }} className={styles.valueText}>{value}</text>
                    }
                </div>
            </div>
        );
    }
    const DisplayRedressal = (key: any, value: any, color) => {
        return (
            <div className={styles.DisplayTableContainer1} style={{ backgroundColor: key == "Appeal from the Complainant" ? "#F4F4F4" : color, marginBottom: '2px' }}>
                <div className={styles.KeyContainer1} style={{ backgroundColor: key == "Appeal from the Complainant" ? "#F4F4F4" : null }} >
                    <text className={styles.keyText1} style={{ color: 'black' }}>{key}</text>
                </div>
                <div className={styles.ValueContainer1}>
                    <text style={{ color: key == "Status" ? StatusColor(value) : null, fontWeight: key == "Status" ? "bold" : null }} className={styles.valueText1}>{value}</text>
                </div>
            </div>
        );
    }

    const isIGNOTReplied = () => {
        let data = ComplaintStatus.commentsList;
        for (let i in data) {
            if (data[i].role == "IG") {
                return false;
            }
        }
        return true;
    }

    const StatusColor = (mystatus: any) => {
        switch (mystatus) {
            case "In Progress": return "#FF5C00";
            case "Appealed to Higher Authority": return "#FF5C00";
            case "Completed": return "#2B8E46";
            case "Submitted": return "#394C90";
            default: return "#333333";
        }
    }
    const fetchFile = (url) => {
        fetch(url).then(res => res.blob()).then(file => {
            let tempUrl = URL.createObjectURL(file);
            const aTag = document.createElement("a");
            aTag.href = tempUrl;
            aTag.download = url.replace(/^.*[\\\/]/, '');
            document.body.appendChild(aTag);
            aTag.click();
            URL.revokeObjectURL(tempUrl);
            aTag.remove();
        }).catch(() => {
            alert("Failed to download file!");
        });
    }

    const DisplayTable2 = (key1, value1, key2, value2, color) => {
        return (
            <div className={styles.detailsInfo} style={{ marginBottom: '2px' }}>
                <div className={styles.detailsCol}>
                    <div className={styles.DisplayTableContainer} style={{ display: 'flex', backgroundColor: color }}>
                        <div className={styles.KeyContainer} style={{ width: '50%' }} >
                            <text className={styles.keyText}>{key1}</text>
                        </div>:
                        <div className={styles.ValueContainer}>
                            <text className={styles.valueText}>{value1}</text>
                        </div>
                    </div>
                </div>
                <div className={styles.detailsCol}>
                    <div className={styles.DisplayTableContainer} style={{ display: 'flex', backgroundColor: color }}>
                        <div className={styles.KeyContainer} style={{ width: '50%' }} >
                            <text className={styles.keyText}>{key2}</text>
                        </div>:
                        <div className={styles.ValueContainer}>
                            <text className={styles.valueText}>{value2}</text>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <>
            <Header />
            <div className='MainContent'>
                <MyNavbar />
                <div className={styles.Container}>
                    <div className={styles.subcontainer} style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ display: "flex", cursor: 'pointer' }}> <Image style={{ cursor: "pointer" }} onClick={() => ComplaintStatus.status ? window.location.reload() : router.push("/")} alt='' width={15} height={15} src="/grievance/images/backbutton.svg"></Image> <text className={styles.TitleText} style={{ marginLeft: "10px" }}>View Status</text></div>
                    </div>
                    {!ComplaintStatus.status && <div className={styles.subcontainer1}>
                        <div className={styles.singlecolumn}>
                            <TableText label="Grievance Id" required={true} LeftSpace={false} />
                            <div className={styles.inputtypes}>
                                <TableInputText name="complaintNo" type="text" placeholder="Enter Grievance Id " required={true} value={InputgravianceId} onChange={onChangeForSearch} />
                            </div>
                        </div>
                        <div className={styles.singlecolumn1}>
                            <button onClick={OnSubmit} className={styles.submitButton}>View Status</button>
                        </div>
                    </div>}
                    {ComplaintStatus.status && <div className={styles.subcontainer}>
                        <div className={styles.title1}>
                            <text className={styles.TitleText1}>{ComplaintStatus.complaintNo} Details</text>
                        </div>
                        {DisplayTable2("Grievance Date", ComplaintStatus.createdAt ? Moment((ComplaintStatus.createdAt)).format("DD-MM-YYYY") : "", "Classification", ComplaintStatus.gravianceClassification, "#F4F4F4")}
                        {DisplayTable2("Person Name", ComplaintStatus.personName, "Mobile Number", ComplaintStatus.phoneNumber, "#F4F4F4")}
                        {DisplayTable2("Email Id", ComplaintStatus.email, "District", ComplaintStatus.district, "#F4F4F4")}
                        {DisplayTable2("Mandal", ComplaintStatus.mandal, "SRO", ComplaintStatus.sro, "#F4F4F4")}
                        {ComplaintStatus.subject ? DisplayTable("Subject", ComplaintStatus.subject, "#F4F4F4") : DisplayTable("Subject", ComplaintStatus && ComplaintStatus.gravianceClassification, "#F4F4F4")}
                        {/* {DisplayTable("Subject", ComplaintStatus.subject, "#F4F4F4")} */}
                        {DisplayTable("Description", ComplaintStatus.description, "#F4F4F4")}
                        {/* {DisplayTable("User Type", ComplaintStatus && ComplaintStatus.userType, "#F4F4F4")} */}
                        {ComplaintStatus.documents && ComplaintStatus.documents.length ? DisplayTable("Document",
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <div style={{ cursor: 'pointer' }} >
                                    <text className={styles.valueText} style={{ fontWeight: "700", cursor: 'pointer', color: 'black' }}>{ComplaintStatus.documents[0].fileName}</text>
                                </div>
                                <div style={{ display: 'flex' }}>
                                    <div style={{ cursor: 'pointer', marginRight: '1rem', display: 'flex' }} onClick={async () => { (await window.open(ComplaintStatus.documents[0].downloadLink)) }}>
                                        <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700", color: 'black' }}>View</text>
                                        <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px', marginRight: '10px' }} src="/grievance/images/eye.svg"></Image>
                                    </div>
                                    <div style={{ cursor: 'pointer', display: 'flex' }} onClick={() => fetchFile(ComplaintStatus.documents[0].downloadLink)}  >
                                        <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700", color: 'black' }}>Download</text>
                                        <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/download.svg"></Image>
                                    </div>
                                </div>
                            </div>
                            , "#F4F4F4") : null}
                        {DisplayTable("Status", ComplaintStatus.complaintStatus, "#F4F4F4")}
                        {ComplaintStatus.commentsList && <div>
                            {ComplaintStatus.commentsList.map((comment: any, index: any) => {
                                return (
                                    <div key={index}>
                                        {(comment.role == "DR" || comment.role == "DIG" || comment.role == "IG")
                                            ?
                                            <div style={{ marginTop: '2rem' }}>
                                                <div className={styles.title} >
                                                    <text className={styles.TitleText}>Redressal by {comment.role == "DR" ? "District Registrar" : "Higher Authority (" + comment.role + ")"}</text>
                                                </div>
                                                {DisplayRedressal("Comments",
                                                    <textarea rows={comment.comment ? 3 + (comment.comment.match(/\n/g) || []).length : 3} disabled={true} style={{ width: '100%', borderColor: 'transparent', borderRadius: '0px', backgroundColor: "#F4F4F4", color: 'black', fontWeight: '500' }} placeholder={'Enter Max 1000 Characters'}
                                                        required={false}
                                                        value={comment.comment} />
                                                    , "#FFFFFF")}
                                                {comment.uploadFile.documents.length ? DisplayRedressal("Documents",
                                                    <div style={{ display: 'flex', paddingTop: '5px', alignItems: 'center' }}>
                                                        <div style={{ cursor: 'pointer' }} >
                                                            <text className={styles.valueText} style={{ marginRight: '50px', fontWeight: "700", cursor: 'pointer' }}>{comment.uploadFile.documents[0].fileName}</text>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', marginRight: '1rem', display: 'flex' }} onClick={async () => { (await window.open(comment.uploadFile.documents[0].downloadLink)) }}>
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>View</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/eye.svg"></Image>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', display: 'flex' }} onClick={() => fetchFile(comment.uploadFile.documents[0].downloadLink)}  >
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>Download</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/download.svg"></Image>
                                                        </div>
                                                    </div>
                                                    , "#FFFFFF") : null}
                                            </div>
                                            :
                                            <div style={{ marginTop: '5rem', backgroundColor: '#F4F4F4', padding: '10px' }}>
                                                {DisplayRedressal("Appeal from the Complainant",
                                                    <TableTextAera value={comment.comment} />
                                                    , "#FFFFFF")}
                                                {comment.uploadFile.documents.length ? DisplayRedressal("Documents",
                                                    <div style={{ display: 'flex', paddingTop: '5px', alignItems: 'center' }}>
                                                        <div style={{ cursor: 'pointer' }} >
                                                            <text className={styles.valueText} style={{ marginRight: '50px', fontWeight: "700", cursor: 'pointer' }}>{comment.uploadFile.documents[0].fileName}</text>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', marginRight: '1rem', display: 'flex' }} onClick={async () => { (await window.open(comment.uploadFile.documents[0].downloadLink)) }}>
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>View</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/eye.svg"></Image>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', display: 'flex' }} onClick={() => fetchFile(comment.uploadFile.documents[0].downloadLink)}  >
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>Download</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/download.svg"></Image>
                                                        </div>
                                                    </div>
                                                    , "#F4F4F4") : null}
                                            </div>
                                        }
                                    </div>
                                )
                            })}</div>
                        }
                        <div className={styles.submit} style={{ marginTop: '4rem' }}>
                            {
                                (!AllowHigherAppeal && ComplaintStatus.commentsList.length && ComplaintStatus.complaintStatus == "Completed" && isIGNOTReplied()) ?
                                    <div style={{ display: 'flex' }}>
                                        <div>Not satisfied with the Redressal? </div>
                                        <div className={styles.submitButton2} onClick={() => setAllowHigherAppeal(true)}>Click Here</div>
                                    </div> : null
                            }
                        </div>
                        {AllowHigherAppeal && ComplaintStatus.complaintStatus == "Completed" &&
                            <form onSubmit={OnSubmitUpdate} style={{ backgroundColor: '#F4F4F4' }}>
                                <div className={styles.hiddencontainer} style={{ marginLeft: '0px', width: '100%' }}>
                                    <div className={styles.Textarea} style={{ marginLeft: '1rem', width: '100%' }}>
                                        <TableText label="Comments" required={true} LeftSpace={false} />
                                        <textarea className={styles.textarea} rows={3} name='comment'
                                            style={{ width: '97%', borderColor: '#AEAEAE', borderRadius: '3px', marginRight: '0px' }}
                                            placeholder={'Enter Max 1000 Characters'}
                                            required={true}
                                            value={ComplaintStatus.comment}
                                            onChange={onChange} />
                                    </div>
                                    <text  style={{ color: 'red',fontSize:'12px' }} >*Note : Please upload only in JPG/JPEG/PNG/PDF format and maximum size 5 MB only.</text>
                                    <div className={styles.uploaddocuments} style={{ marginLeft: '1rem' }}>
                                        <TableText label="Upload Documents" required={false} LeftSpace={false} />
                                        <UploadDoc onCancelUpload={onCancelUpload} isUploadDone={ComplaintStatus.sroUploadDocuments} label="" required={false} uploadKey={"sroUploadDocuments"} onChange={(e: any) => { OnFileSelect(e, "documents", "sroUploadDocuments"); }} />
                                    </div>
                                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                                        <button className={styles.submitButtonsro}>Submit</button>
                                    </div>
                                </div>
                            </form>
                        }
                    </div>}
                </div>
            </div>
        </>
    );
};
export default GrievanceStatus;