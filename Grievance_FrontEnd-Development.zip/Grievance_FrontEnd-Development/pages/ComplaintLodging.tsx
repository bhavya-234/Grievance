import React, { useState, useEffect, useLayoutEffect } from 'react'
import styles from '../styles/pages/ComplaintLodging.module.scss';
import UploadDoc from '../src/components/UploadDoc';
import TableInputText from '../src/components/TableInputText';
import TableText from '../src/components/TableText';
import TableDropdown from '../src/components/TableDropdown';
import { LoadingAction, PopupAction } from '../src/redux/commonSlice';
import { useAppDispatch, useAppSelector } from '../src/redux/hooks';
import { useRouter } from 'next/router';
import { useUploadDocbyuser, useSaveComplaintDetails, useGetDistrict, useGetMandal, useGetSRO, sendotp, verifyotp, resendotp } from '../src/axios';
import { MdNearbyError } from 'react-icons/md';
import MyNavbar from '../src/components/MyNavbar';
import { Header } from '../src/components/Header';
import TableInputRadio from '../src/components/TableInputRadio';
import TableDropDownData from '../src/components/TableDropDownData';
const ComplaintLodging = () => {
  const dispatch = useAppDispatch()
  const router = useRouter()
  const initialComplaintDetails = {
    personName: "",
    phoneNumber: "",
    email: "",
    district: "",
    mandal: "",
    sro: "",
    gravianceClassification: "",
    subject: "",
    otp:"",
    description: "",
    complaintStatus: "Submitted",
    documents: [],
    userUploadDocuments: "",
    sroUploadDocuments: "",
    otpID:"",
    userType:""
  }
  let [display1, setdisplay1] = useState<Boolean>(false)
  let [display, setdisplay] = useState<Boolean>(false)
  const [ComplaintDetails, setComplaintDetails] = useState<any>(initialComplaintDetails);
  const [DistrictList, setDistrictList] = useState<any>([]);
  const [otpID, setOtpID] = useState<any>("");
  const [changes, setchanges] = useState<any>('enable');
  const [MandalList, setMandalList] = useState<any>([]);
  const [SROList, setSROList] = useState<any>([]);
  const [SelectedMandal, setSelectedMandal] = useState<any>("");
  const [SelectedDistrict, setSelectedDistrict] = useState<any>([]);
  const [FormErrors, setFormErrors] = useState<any>({});
  const [displaysub, setdisplaysub] = useState<boolean>(false)
  const [displaysubject, setdisplaysubject] = useState<boolean>(false)
  const Loading = (value: boolean) => { dispatch(LoadingAction({ enable: value })); }
  const redirectToPage = (location: string, query: {}) => {
    router.push({
      pathname: location,
      query:query
    })
  }
 
  useEffect(()=>{
    let [rest,path]=window.location.href.split("="); 
  if(path){
    let compdata ={...ComplaintDetails,gravianceClassification:path.toLocaleUpperCase()};
    setComplaintDetails(compdata);
	if("E-CHITS" === path.toLocaleUpperCase())
		setdisplaysub(true)
  }else{  
    return;
    
  }
  },[])
  const resetPopup: any = async () => { setPopup({ ...Popup, enable: true, type: false }) }
  const onChange = (e: any) => {
    let MyComplaintDetails = ComplaintDetails;
    let addName = e.target.name
    let addValue = e.target.value == (e.target.value == "SELECT") ? "" : e.target.value;
    if (addName == "gravianceClassification") {
      
      if (addValue == "ANY OTHER") {
        setdisplaysubject(true)
      }
      else {
        setdisplaysubject(false);
        MyComplaintDetails = { ...MyComplaintDetails, subject: '' }
      }
    }
    if (addName == "personName") {
      addValue = addValue.replace(/[^\w\s]/gi, "");
      addValue = addValue.replace(/[0-9]/gi, "");
    }

    if (addName == "phoneNumber") {
      if (parseInt(addValue) == parseInt(ComplaintDetails.phoneNumber) + 1 || parseInt(addValue) == parseInt(ComplaintDetails.phoneNumber) - 1) {
        addValue = ComplaintDetails.phoneNumber;
      }
      let errorLabel = ""
      if (addValue.length < 10) {
        errorLabel = "Enter 10 Digit Valid Mobile Number";
      }
      if (addValue.length > 10) {
        addValue = addValue.substring(0, 10);
      }
      setFormErrors({ ...MdNearbyError, phoneNumber: errorLabel })
    } else if(addName=="otp"){
      if (addValue.length > 6) {
        addValue = addValue.substring(0, 6);
      }
    }else if (addName == "subject") {
      if (addValue.length > 120) {
        addValue = addValue.substring(0, 120);
      }
    } else if (addName == "description") {
      if (addValue.length > 1000) {
        addValue = addValue.substring(0, 1000);
      }
      addValue = addValue.replace(/[$&@#|{}'<>.^!]/, "");
    }
    else if (addName == "personName") {
      if (addValue.length > 50) {
        addValue = addValue.substring(0, 50);
      }
    }
    setComplaintDetails({ ...MyComplaintDetails, [addName]: addValue })
  };
  const DropDownList = {
    classificationlist: [{ value: "REGISTRATION", label: "REGISTRATION" }, { value: "EC", label: "EC" }, { value: "CC", label: "CC" }, { value: "MARKET VALUE", label: "MARKET VALUE" },
    { value: "SALE OF STAMPS", label: "SALE OF STAMPS" }, { value: "FRADULENT REGISTRATIONS", label: "FRADULENT REGISTRATIONS" }, { value: "PROHIBITED PROPERTIES", label: "PROHIBITED PROPERTIES" },
    { value: "EDIT INDEX", label: "EDIT INDEX" }, { value: "IMPOUNDING", label: "IMPOUNDING" }, { value: "MARKET ANOMALY", label: "MARKET ANOMALY" }, { value: "NOTARY", label: "NOTARY" },{ value: "E-CHITS", label: "E-CHITS" }, { value: "ANY OTHER", label: "ANY OTHER" }],
  }
  const Radiobutton={
    list:[{value: "CITIZEN", label: "CITIZEN"},{value: "INDUSTRIAL", label: "INDUSTRIAL"}],
    echitslist:[{value: "SUBSCRIBER", label: "SUBSCRIBER"},{value: "NON SUBSCRIBER", label: "NON SUBSCRIBER"}]

  }
 
  const OnSubmit = async (e: any) => {
    e.preventDefault();
    let myError: any = validate(ComplaintDetails)
    setFormErrors(myError)
    if (Object.keys(myError).length === 0) {
      // ComplaintDetails.otpID = otpID;
      await CallSaveComplaintDetails(ComplaintDetails);
    }
  };
  // const verify = (e:any) => {
    
  //   let addValue = ComplaintDetails.phoneNumber.trim();
  //   if (addValue.length != 10) {
  //     return ShowAlert(false,"Enter 10 Digit Valid Mobile Number","")
  //     // errorLabel = "Enter 10 Digit Valid Mobile Number";
  //   }
    
  //   CallSendOtpDetails()
  //   setdisplay(true)
  // }
  // const verified = (e:any) => {
  //   let addValue = ComplaintDetails.otp.trim();
  //   if (addValue.length != 6) {
  //     return ShowAlert(false,"Enter 6 Digit Valid otp","")
  //   }
  //   e.preventDefault();
  //   CallVerifyOtpDetails()
    

  //   // setdisplay1(true)
  // }
  // const resend=(e:any)=>{
  //   e.preventDefault();
  //   CallResendOtpDetails()
   
  // }
  const CallSaveComplaintDetails = async (details: any) => {
    Loading(true);
    let result = await useSaveComplaintDetails(details);
    Loading(false);
    if (result.status) {
      ShowAlert(true, result.data.complaintNo +" "+ result.message, "/");
      console.log("data", ComplaintDetails)
    }
    // else { ShowAlert(false,"please validate your mobile number before submitting the grievance", ""); }
    else { ShowAlert(false,"Failed", "");}
  }
  
  const CallSendOtpDetails = async () => {
    Loading(true);
    let data = { phoneNumber: ComplaintDetails.phoneNumber }
    let result = await sendotp(data);
    Loading(false);
    if (result.status) {
      setOtpID(result.data.id);
      ShowAlert(true, result.message, "");
    }
    else { ShowAlert(false, result.message, ""); }
  }
  const CallVerifyOtpDetails = async () => {
    Loading(true);
    let result = await verifyotp(otpID,ComplaintDetails.otp);
    Loading(false);
    if(result.status) {
      ShowAlert(true,result.message, "");
      setdisplay1(true)
    }
    else{ ShowAlert(false, result.message, ""); 
    setdisplay1(false)
  } 
  }
  const CallResendOtpDetails = async () => {
    Loading(true);
    let result = await resendotp(otpID);
    Loading(false);
    if (result.status) {
      ShowAlert(true, result.message, "");
    }
    else { ShowAlert(false, result.message, ""); }
  }
  const validate = (values: any) => {
    type errors = {
      phoneNumber?: string;
      abc?: string;
    };
    const errorList: errors = {}
    if (values.phoneNumber.length != 10) errorList.phoneNumber = "Enter 10 Digit Valid Mobile Number.";
    return errorList;
  }
  const ShowAlert = (type, message, redirectLocation) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirectLocation })); }
  const ForUploadDoc = async (data: any, formData: any, uploadName: string, loginType: any) => {
    Loading(true);
    let result = await useUploadDocbyuser(data, formData);
    Loading(false);
    if (result.status) {
      let documents = [];
      documents.push(result.data);
      setComplaintDetails({ ...ComplaintDetails, [uploadName]: "true", documents });
    }
    else {
      setComplaintDetails({ ...ComplaintDetails, [uploadName]: "false" });
    }
  }
  const OnFileSelect = async (event: any, docName: string, uploadName: string) => {
    if (event.target.files.length) {
      if (event.target.files[0].size > 5245329) {
        ShowAlert(false, "File size should not be more than 5MB.", "");
        event.target.value = "";
      }
      else {
        const file = event.target.files[0];
        console.log(file)
        let fileNamesSplit = file.name.split('.');
        let validFileExtensions = ["jpg", "jpeg", "bmp", "png", "pdf"];
        if (fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])) {
          ShowAlert(false, "Irrelevant file type. Only image/pdf can be uploaded.", "");
          event.target.value = "";
        }
        else {
          setComplaintDetails({ ...ComplaintDetails, [uploadName]: "process" });
          const formData = new FormData();
          formData.append('image', event.target.files[0]);
          let data: any = {
            docName: docName,
          }
          await ForUploadDoc(data, formData, uploadName, "");
        }
      }
    } else {
      ShowAlert(false, "", "")
    }
  }
  const verifiedchanges=()=>{
    setchanges('disable')
  }
  useLayoutEffect(() => {
    localStorage.clear();
  }, []);

  useEffect(() => { GetDistrict() }, []);
  const GetDistrict = async () => {
    Loading(true);
    let result = await useGetDistrict();
    Loading(false);
    if (result && result.status) {
        setDistrictList(result.data)
    }
  }
  const CallMandal = async (value) => {
    setSelectedDistrict(value);
    setSROList([]);
    Loading(true);
    let result = await useGetMandal(value);
    Loading(false);
    if (result.status) {
      setMandalList(result.data);
    }
  }

  const CallSRO = async (value) => {
    setSelectedMandal(value);
    Loading(true);
    let result = await useGetSRO(SelectedDistrict + '&mandal=' + value);
    Loading(false);
    if (result.status) { setSROList(result.data); } else {
      ShowAlert(false, result.message, "")
    }

  }
  const CallSROofficer = async (value) => {
    Loading(true);
    let result = await useGetSRO(SelectedDistrict + '&sroName=' + value);
    Loading(false);
    if (result.status) {
      setComplaintDetails({ ...ComplaintDetails, sro: value })
    }
    else {
      ShowAlert(false, result.message, "")
    }
  }
  const ForSROSelect = async (event: any, location: string) => {

    if (location == "district") {
      setMandalList([]);
      setSROList([]);
      setComplaintDetails({ ...ComplaintDetails, district: event.target.value })
      await CallMandal(event.target.value)
    }

    if (location == "mandal") {
      setSROList([]);
      setComplaintDetails({ ...ComplaintDetails, mandal: event.target.value })
      await CallSRO(event.target.value);
    }
    if (location == "sro") {
      setComplaintDetails({ ...ComplaintDetails, sro: event.target.value })
    }
  }

  const onCancelUpload = (uploadKey) => {
    setComplaintDetails({ ...ComplaintDetails, [uploadKey]: "", documents: [] });
  }
  const [Popup, setPopup] = useState<any>({
    enable: false,
    type: true,
  });
  return (
    <>
      <Header />
      <div className='MainContent'>
        <MyNavbar />
        <form onSubmit={OnSubmit} className={styles.Container}>
          <div className={styles.title}>
            <text className={styles.TitleText}>Lodge Grievance</text></div>
            <div className={styles.subcontainer}>
            <div className={styles.tableContainer}>
              <TableText label="Who is Lodging grievance?" required={true} LeftSpace={false} />
          
              {!displaysub&&<TableInputRadio required={true} label="" options ={Radiobutton.list} defaultValue={ComplaintDetails.userType} name="userType" onChange={onChange}/>
            } {displaysub &&<TableInputRadio required={true} label="" options ={Radiobutton.echitslist} defaultValue={ComplaintDetails.userType} name="userType" onChange={onChange}/>
}
        </div> </div> <div className={styles.subcontainer}>
            <div className={styles.tableContainer}>
              <TableText label="Full Name" required={true} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <TableInputText name="personName" type="text" placeholder="Enter Full Name" required={true} value={ComplaintDetails.personName.toUpperCase()} onChange={onChange} />
              </div>
            </div>
            <div className={styles.tableContainer}>
              <TableText label="Contact Number" required={true} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <div>
                  <TableInputText name="phoneNumber" type="number" placeholder="Enter Contact Number " required={true} value={ComplaintDetails.phoneNumber} onChange={onChange} />
                   </div>  
                 <text className={styles.warningText} style={{ color: 'red' }}>{FormErrors.phoneNumber}</text>
              </div>


              {/* {!display&&<div className={styles.inputtypes}> */}
              {/* <div className={styles.inputtypes}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <div style={{width:"55%"}}>
                  <TableInputText name="phoneNumber" type="number" placeholder="Enter Contact Number " required={true} value={ComplaintDetails.phoneNumber} onChange={onChange} />
                </div> 
                <div style={{display:"flex-end"}}> <button onClick={verify} className={styles.submitButtonotp}>SEND OTP</button></div>
                </div>  
                 <text className={styles.warningText} style={{ color: 'red' }}>{FormErrors.phoneNumber}</text>
              </div> */}
              {/* {display&&<div>{!display1&&<div className={styles.inputtypes}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  
                  <TableInputText name="otp" type="number" placeholder="Enter otp " required={true} value={ComplaintDetails.otp} onChange={onChange} />
                  <button onClick={verified} className={styles.submitButtonverify}>verify</button>
                  <div style={{display:"flex-end",justifyContent:"space-between"}}><button onClick={resend} className={styles.submitButtonverify}>resend</button></div>
                </div>
              </div>}</div>}
              {display1&&<div className={styles.inputtypes}>
                  <TableInputText name="phoneNumber" type="number" placeholder="Enter Contact Number " required={true} value={ComplaintDetails.phoneNumber} onChange={verifiedchanges} />
               </div>} */}
            </div>
            <div className={styles.tableContainer}>
              <TableText label="Email ID" required={true} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <TableInputText name="email" type="email" placeholder="Enter Email ID " required={true} value={ComplaintDetails.email} onChange={onChange} />
              </div>
            </div>
          </div>
          <div className={styles.subcontainer}>
            <div className={styles.tableContainer}>
              <TableText label="District" required={true} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <TableDropdown required={true} options={DistrictList} sro={true} name="district" value={ComplaintDetails.district} onChange={(e: any) => ForSROSelect(e, "district")} />
              </div>
            </div>
            <div className={styles.tableContainer}>
              {!displaysub&&<><TableText label="Mandal" required={true} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <TableDropdown required={true} options={MandalList} sro={true} name="mandal" value={ComplaintDetails.mandal} onChange={(e: any) => ForSROSelect(e, "mandal")} />
                  
              </div></>}
              {displaysub&&<><TableText label="Mandal" required={false} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <TableDropdown required={false} options={MandalList} sro={true} name="mandal" value={ComplaintDetails.mandal} onChange={(e: any) => ForSROSelect(e, "mandal")} />
              </div></>}
            </div>
            <div className={styles.tableContainer}>
             {!displaysub&&<> <TableText label="SRO" required={true} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <TableDropdown required={true} options={SROList} sro={true} name="sro" value={ComplaintDetails.sro} onChange={(e: any) => ForSROSelect(e, "sro")} />
                </div></>}
                {displaysub&&<> <TableText label="SRO" required={false} LeftSpace={false} />
              <div className={styles.inputtypes}>
                <TableDropdown required={false} options={SROList} sro={true} name="sro" value={ComplaintDetails.sro} onChange={(e: any) => ForSROSelect(e, "sro")} />
                </div></>}
            </div>
          </div>
          <div className={styles.subcontainer}>
            <div className={styles.tableContainer}>
              <TableText label="Grievance Classification" required={true} LeftSpace={false} />
              
              <div className={styles.inputtypes1}>
                <TableDropDownData required={true} onChange={onChange} options={DropDownList.classificationlist} name="gravianceClassification" keyName="label" errorMessage={''} value={ComplaintDetails.gravianceClassification} keyValue="value" />
                {/* <TableDropdown required={true} options={DropDownList.classificationlist} name="gravianceClassification" value={ComplaintDetails.gravianceClassification} onChange={onChange} /> */}
              </div>
            </div>
            {displaysubject &&
              <div className={styles.tableContainer}>
                <TableText label="Subject" required={true} LeftSpace={false} />
                <div className={styles.inputtypes}>
                  <TableInputText name="subject" value={ComplaintDetails.subject} type="text" placeholder="Enter Max 120 Characters" required={true} onChange={onChange} />
                </div>
              </div>}
            <div className={styles.tableContainer}></div>
          </div>
          <div className={styles.subcontainer}>
            <div className={styles.tableContainer1}>
              <TableText label="Description" required={true} LeftSpace={false} />
              <div className={styles.Description}>
                <textarea rows={3} style={{ width: '100%', borderColor: '#AEAEAE', borderRadius: '3px' }} placeholder={'Enter Max 1000 Characters'}
                  required={true}
                  value={ComplaintDetails.description}
                  name="description"
                  onChange={onChange}>
                </textarea>
              </div>
            </div>
          </div>
          <div className={styles.uploaddocuments}>
            <text style={{ color: 'red', fontSize: '12px' }} >*Note : Please upload only in JPG/JPEG/PNG/PDF format and a maximum size of 5 MB only.</text>
            <UploadDoc isUploadDone={ComplaintDetails.userUploadDocuments} label="Upload Documents" required={true} uploadKey={"userUploadDocuments"} onCancelUpload={onCancelUpload} onChange={(e: any) => { OnFileSelect(e, "documents", "userUploadDocuments"); }} />
          </div>
          <div className={styles.subcontainer}>
            <button className={styles.submitButton}>Submit</button>
          </div>
        </form>
      </div>
    </>
  )
}

export default ComplaintLodging



