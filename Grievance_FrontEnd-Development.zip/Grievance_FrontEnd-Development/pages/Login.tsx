import React, { useLayoutEffect } from 'react'
import { Fragment, useState, useEffect } from 'react';
import TableInputText from '../src/components/TableInputText';
import styles from '../styles/pages/Login.module.scss';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useAppSelector, useAppDispatch } from '../src/redux/hooks';
import { LoadingAction, PopupAction } from '../src/redux/commonSlice';
import { saveLoginDetails } from '../src/redux/loginSlice';
import { useSingup, useUserLogin, useOfficerLogin } from '../src/axios';

import MyNavbar from '../src/components/MyNavbar';
import { Header } from '../src/components/Header';
const Login = () => {
  const dispatch = useAppDispatch()
  const router = useRouter()
  const redirectToPage = (location: string, query: {}) => {
    router.push({
      pathname: location,
    })
  }
  const LoginTypes = [
    { key: 0, label: 'User Login', name: false, email: true, mobile: false, pswd: true, rpswd: false, buttonName: 'Login' },
    { key: 1, label: 'Department Login', name: false, email: true, mobile: false, pswd: true, rpswd: false, buttonName: 'Login' },
    { key: 2, label: 'New Registration!', name: true, email: true, mobile: true, pswd: true, rpswd: true, buttonName: 'Register' },
    { key: 3, label: 'Forgot Password', name: false, email: true, mobile: true, pswd: false, rpswd: false, buttonName: 'Verify' }
  ];
  const initialLoginDetails = {
    loginLabel: '',
    loginName: '',
    lastLogin:'',
    loginEmail: '',
    loginMobile: '',
    loginPassword: '',
    loginRPassword: '',
    sroNumber: ''
  }
  const [SelectedLoginType, setSelectedLoginType] = useState<number>(1);
  const [LoginDetails, setLoginDetails] = useState(initialLoginDetails);
  const [FormErrors, setFormErrors] = useState<any>({});


  useLayoutEffect(() => {
    localStorage.clear();
  }, []);

  useEffect(() => { dispatch(saveLoginDetails(initialLoginDetails)); });
  
  const Loading = (value: boolean) => {dispatch(LoadingAction({enable:value}));}

  const onChange = (e: any) => {
    setLoginDetails({ ...LoginDetails, [e.target.name]: e.target.value })
  }

  const onSubmit = (e: any) => {
    e.preventDefault();

    let myError: any = validate(LoginDetails)
    setFormErrors(myError)

    if (Object.keys(myError).length === 0) {
      switch (SelectedLoginType) {
        case 0: UserLoginAction(); break;
        case 1: OfficerLoginAction(); break;
        case 2: RegisterAction(); break;
        default: break;
      }
    }
  }

  const validate = (values: any) => {
    type errors = {
      loginEmail?: string;
      loginMobile?: string;
      loginRPassword?: string;
      loginPassword?: string;
      loginName?: string;
    };
    const obj: errors = {}

    if (SelectedLoginType == 2 && values.loginName.trim().length == 0) {
      obj.loginName = "Empty person name is not allowed.";
    }

    if ((SelectedLoginType == 2 || SelectedLoginType == 3) && values.loginMobile.length != 10) {
      obj.loginMobile = "Enter 10 digit valid mobile number.";
    }

    if (SelectedLoginType == 2 && values.loginPassword.length < 6) {
      obj.loginPassword = "Minumum 8 digits password required";
    }

    if (SelectedLoginType == 2 && values.loginRPassword != values.loginPassword) {
      obj.loginRPassword = "Password does not match.";
    }

    return obj;
  }

  const UserLoginAction = async () => {

    try {
      let data = {
        loginEmail: LoginDetails.loginEmail,
        loginPassword: LoginDetails.loginPassword
      }

      await CallLogin(data);
    } catch (error) {
      ShowAlert(false, "Error:" + error, "");
    }
  }

  const CallLogin = async (value: any) => {
    Loading(true);
    let result: any = await useUserLogin(value);
    Loading(false);
    if (result && result.status) {
      let query = {
        loginId: result.data.loginId,
        loginEmail: result.data.loginEmail,
        loginName: result.data.loginName,
        lastLogin:result.data.lastLogin,
        token: result.data.token,
        appNo: result.data.appNo,
        loginType: result.data.loginType,
        status: result.data.status
      }
      dispatch(saveLoginDetails(query));
      router.push({
        pathname: '/Userdashboard',
      })
    } else {
      ShowAlert(false, result.message, "");
    }
  }

  const ShowAlert = (type, message, redirectLocation) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirectLocation })); }

  const OfficerLoginAction = async () => {

    try {
      let data = {
        loginEmail: LoginDetails.loginEmail,
        loginPassword: LoginDetails.loginPassword
      }

      await CallOfficeLogin(data);
    } catch (error) {
      ShowAlert(false, "Error:" + error, "");
    }
  }

  const CallOfficeLogin = async (value: any) => {
    Loading(true);
    let result: any = await useOfficerLogin(value);
    Loading(false);
    if (result && result.status) {
      let query = {
        loginId: result.data.loginId,
        loginEmail: result.data.loginEmail,
        loginName: result.data.loginName,
        lastLogin:result.data.lastLogin,
        token: result.data.token,
        loginType: result.data.loginType,
        sroDistrict: result.data.sroDistrict,
        sroMandal: result.data.sroMandal,
        sroOffice: result.data.sroOffice,
        sroNumber: result.data.sroNumber,
        role: result.data.role,
        district: result.data.district,
        sro: result.data.sro
  
      }
      localStorage.setItem("loginDetails", JSON.stringify(query));
      dispatch(saveLoginDetails(query));
      router.push({
        pathname: '/Dashboard',
      })
      // localStorage.setItem('LoginUser', JSON.stringify(result.data));
    } else {
      ShowAlert(false, result.message, "");
    }
  }

  const RegisterAction = async () => {

    try {
      let data = {
        loginEmail: LoginDetails.loginEmail,
        loginType: "user",
        loginName: LoginDetails.loginName,
        loginMobile: LoginDetails.loginMobile,
        loginPassword: LoginDetails.loginPassword
      }

      await CallSignUp(data);
    } catch (error) {
      ShowAlert(false, "Error:" + error, "");

    }
  }

  const CallSignUp = async (value: any) => {
    Loading(true);
    let result: any = await useSingup(value);
    Loading(false);
    if (result && result.status) {
      ShowAlert(true, "User Created Successfully.", "");
      setSelectedLoginType(0);
    } else {
      ShowAlert(false, "Error:" + "Register User Failed", "");
    }
  }

  const [eye1, setEye1] = useState<boolean>(false);







  return (
    <div>
      <Header/>
    {/* <div> */}
    <div className='MainContent'>
      <MyNavbar/>
      <form onSubmit={onSubmit} className={styles.container} autoComplete='off'>
        <div className={styles.leftContainer}>

          <div className={styles.frameContainer}>

            <Image alt='' width={400} height={370} className={styles.image} src="/grievance/images/loginimage.svg"></Image>

          </div>
        </div>

        <div  className={styles.rightContainer}>
          <text className={styles.TitleText}>{LoginTypes[SelectedLoginType].label}</text>
          {
            LoginTypes[SelectedLoginType].name && <div style={{ paddingTop: '5%', margin: 'auto' }}>
              <text className={styles.keyText}>Full Name :</text>
              <TableInputText name={'loginName'} type='text' placeholder='Firstname Lastname' required={true} value={LoginDetails.loginName} onChange={onChange} />
              <text className={styles.warningText}>{FormErrors.loginName}</text>
            </div>
          }
          {
            LoginTypes[SelectedLoginType].email && <div style={{ paddingTop: '5%', margin: 'auto' }}>
              <text className={styles.keyText}>Email Address :</text>
              <TableInputText name={'loginEmail'} type='email' placeholder='Enter registered email address' required={true} value={LoginDetails.loginEmail} onChange={onChange} />
            </div>
          }
          {
            LoginTypes[SelectedLoginType].mobile && <div style={{ paddingTop: '3%', margin: 'auto' }}>
              <text className={styles.keyText}>Mobile Number :</text>
              <TableInputText name={'loginMobile'} type='number' placeholder='Enter mobile number' required={true} value={LoginDetails.loginMobile} onChange={onChange} />
              <text className={styles.warningText}>{FormErrors.loginMobile}</text>
            </div>
          }
          {
            LoginTypes[SelectedLoginType].pswd && <div style={{ paddingTop: '3%', margin: 'auto' }}>
              <text className={styles.keyText}>Password :</text>
              <div style={{position:'relative'}}>
              <TableInputText name={'loginPassword'} type={eye1?"text":"Password"} placeholder='Enter password' required={true} value={LoginDetails.loginPassword} onChange={onChange} />
              <div className={styles.icon} onClick={() => { setEye1(!eye1) }}>
              {/* <Image alt='' height={14} width={20} src={eye1 ? "/grievance/images/eye.svg" : "/grievance/images/eye_hide.svg"} /></Image> */}
              <Image alt='' width={14} height={20} src={eye1?"/grievance/images/eye.svg":"/grievance/images/eye_hide.svg"}></Image>

              </div></div>
              <text className={styles.warningText}>{FormErrors.loginPassword}</text>
            </div>
          }
          {
            LoginTypes[SelectedLoginType].rpswd && <div style={{ paddingTop: '3%', margin: 'auto' }}>
              <text className={styles.keyText}>Confirm Password :</text>
              <TableInputText name={'loginRPassword'} type='password' placeholder='Enter password again' required={true} value={LoginDetails.loginRPassword} onChange={onChange} />
              <text className={styles.warningText}>{FormErrors.loginRPassword}</text>
            </div>
          }
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '5px' }}>
            </div>
          <div className={styles.loginButtonContainer}>
            <button className={styles.loginButton}> <text className={styles.buttonText}>{LoginTypes[SelectedLoginType].buttonName}</text></button>
          </div>
        </div>
      </form>
      </div>  
     </div>
  )
}

export default Login


