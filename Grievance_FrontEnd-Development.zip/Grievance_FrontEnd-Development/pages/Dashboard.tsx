import React, { Fragment, useEffect, useLayoutEffect, useState } from 'react'
import { useRouter } from 'next/router';
import ResetPassword from '../src/components/ResetPassword';
import Moment from 'moment';
import dastyles from '../styles/pages/Dashboard.module.scss'
import { UseGetcomplaintListDr, GetStatusCount, Updatestatus, OfficerLogout } from '../src/axios';
import { UseGetcomplaintList } from '../src/axios';
import { useAppSelector, useAppDispatch } from '../src/redux/hooks';
import { saveGravienceID, saveLoginDetails } from '../src/redux/loginSlice';
import { Header } from '../src/components/Header';
import { LoadingAction, PopupAction } from '../src/redux/commonSlice';

const Dashboard = () => {
    const dispatch = useAppDispatch()
    let initialLoginDetails = useAppSelector((state) => state.login.loginDetails);
    const [LoginDetails, setLoginDetails] = useState(initialLoginDetails);
    const router = useRouter();
    const [Popup, setPopup] = useState<any>({
        enable: false,
        type: true,
    });
    let [complaintList, setcomplaintList] = useState<any>({});
    let [statuscount, setstatuscount] = useState<any>([]);
    let [display, setdisplay] = useState<Boolean>(false)
    const [pagenumber, setpagenumber] = useState(1)
    let [flag, setflag] = useState<string>("")
    const [searchQuery, setSearchQuery] = useState('')
    const Loading = (value: boolean) => { dispatch(LoadingAction({ enable: value })); }
    useEffect(() => {
        let data: any = localStorage.getItem("loginDetails");
        data = JSON.parse(data);
        if (data && data.token) {
            setLoginDetails(data)
        }
        else {
            router.push("/Login");
        }
    }, [])
    useEffect(() => {
        let data: any = localStorage.getItem("loginDetails");
        data = JSON.parse(data);
        if (data && data.token && (data.loginType == "OFFICER" || data.loginType == "officer")) {
            handlecountstatus();
        }
        else {
            router.push("/Login");
        }
    }, [])
    const viewDetails = (appNo: any) => {
        let details = { ...LoginDetails, appNo: appNo }
        dispatch(saveLoginDetails(details));
    }
    const CallGetcomplaintList = async (status: any, page, search) => {
        let login: any = localStorage.getItem("loginDetails");
        login = JSON.parse(login);
        if (!login) { return }
        if (login.role == "DR") {
            let location = "district=" + login.district;
            Loading(true);
            let result = await UseGetcomplaintListDr(status, location, page, search, login.loginId);
            Loading(false);
            if (result.status) {
                await setcomplaintList(result.data)
            } else {
                ShowAlert(false, result.message, "")
            }
        }
        else {
            Loading(true);
            let result = await UseGetcomplaintList(status, page, login.loginId, search);
            Loading(false);
            if (result.status) {
                setcomplaintList(result.data);
            } else {
                ShowAlert(false, result.message, "")
            }
        }
    }
    const redirectToPage = (location: string, query: {}) => {
        router.push({
            pathname: location,
            // query: query,
        })
    }
    const onselectcomplaint = async (complaintNo: string, status: string, loginType: any) => {
        localStorage.setItem("complaintNo", complaintNo);
        dispatch(saveGravienceID(complaintNo))
        if (status == "Submitted" || status == "Appealed to Higher Authority") {
            await updatestatusinfo(complaintNo);
        }
        redirectToPage("/DetailsForSro", {})
    }
    const current = new Date();
    const date: any = `${current.getFullYear()}-${current.getMonth() + 1}-${current.getDate()}`;
    const Calculatedays = (complaintdate: any) => {
        const date1: any = new Date(complaintdate);
        const current: any = new Date();
        const date = `${current.getFullYear()}-${current.getMonth() + 1}-${current.getDate()}`;
        const currentdate: any = new Date(date);
        const diffTime = Math.abs(currentdate - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    }
    const pagenumbers = []
    for (let i = 1; i < Math.ceil(complaintList.totalCount / 10) + 1; i++) {
        pagenumbers.push(i)
    }
    const [sno, setsno] = useState(0)
    const pagehandler = (page: any) => {
        setpagenumber(page)
        setsno((page - 1) * 10)
        CallGetcomplaintList("ALL", page, searchQuery)
    }
    const [style, setstyle] = useState("#086EA7")
    const [style1, setstyle1] = useState("#1AA3E3")
    useEffect(() => {
        const getData = setTimeout(() => {
            CallGetcomplaintList("ALL", pagenumber, searchQuery)
        }, 1000)
        return () => clearTimeout(getData)
    }, [searchQuery])
    const handleclickpending = () => {
        CallGetcomplaintList("Appealed to Higher Authority", pagenumber, '')
        setpagenumber(1)
        setsno(0)
        setflag("Appealed to Higher Authority")
        setstyle("#086EA7")
        setstyle1("#1AA3E3")
        setdisplay(false)

    }
    const handleclickcompleted = () => {
        CallGetcomplaintList("REPLIED", pagenumber, '')
        setsno(0)
        setpagenumber(1)
        setflag("REPLIED")
        setstyle1("#086EA7")
        setstyle("#1AA3E3")
        setstyle1("#086EA7")
        setdisplay(true)
    }
    const handlecountstatus = async () => {
        let data: any = localStorage.getItem("loginDetails");
        data = JSON.parse(data);
        let result: any = await GetStatusCount(data.loginId)
        console.log(result);
        if (result.status) {
            setstatuscount([{ ...result.data, id: 1 }]);
        } else {
            ShowAlert(false, result.message, "")
        }
    }
    let srno = sno
    const updatestatusinfo = async (complaintNo) => {
        let data = {
            complaintStatus: "In Progress",
            complaintNo: complaintNo
        };
        Loading(true);
        let result = await Updatestatus(data);
        Loading(false);
        if (result.status) {
        } else {
            console.log('Update failed');
        }
    }
    const resetPopup: any = async () => { setPopup({ ...Popup, enable: true, type: false }) }
    const ShowAlert = (type, message, redirectLocation) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirectLocation })); }

    const onLogout = () => {
        OfficerLogout();
        setTimeout(() => { localStorage.clear(); }, 200);
        setTimeout(() => {
            router.push("/Login");
        }, 0)
        // localStorage.removeItem('LoginUser');
    }
    return (
        <>
            <ResetPassword enable={Popup.enable} setPopup={setPopup} Popup={Popup} />
            <Header />
            <div className='MainContent'>
                <div className={dastyles.Navbar}><text className={dastyles.NavbarText}> Welcome: {LoginDetails.loginName}({LoginDetails && LoginDetails.role.toUpperCase()}) {LoginDetails.role == 'DR' ? <text>{LoginDetails.district}</text> : null}  [<text className={dastyles.NavbarText}> Last Login : {LoginDetails.lastLogin}</text>]
                </text>
                    <div style={{ display: "flex", paddingTop: "2px" }}>
                        <button className={dastyles.navbarbutton} style={{ marginRight: '1rem', cursor: 'pointer' }} onClick={resetPopup}>Reset Password</button>
                        <button style={{ cursor: 'pointer' }} className={dastyles.navbarbutton} onClick={onLogout} > Logout</button>
                    </div>
                </div>
                <div className={dastyles.container} style={{ marginBottom: '1%' }}>
                    <div className={dastyles.headcontent}>
                        <div>
                            <h2 className={dastyles.title}> Dashboard</h2>
                        </div>
                        <input type='text' style={{ fontSize: '12px' }} onChange={(e) => { setSearchQuery(e.target.value) }} placeholder='Search by Classification' />
                    </div>
                    <div className={dastyles.tableFixHeadstatus}>
                        <table className={dastyles.tablecontainerstatus}>
                            <thead>
                                <tr>
                                    <th className={dastyles.box1}>New</th>
                                    <th className={dastyles.box2}>In Progress</th>
                                    <th className={dastyles.box3}>Completed</th>
                                    <th className={dastyles.box4}>Closed</th>
                                    <th className={dastyles.box5}>Appealed to Higher Authority</th>
                                    <th className={dastyles.box6}>Auto Escalated</th>
                                    <th className={dastyles.box7}>Total Complaints </th>
                                </tr>
                            </thead>
                            <tbody>
                                {statuscount.map((count: any, index: any) => {
                                    return (
                                        <tr key={index} style={{ backgroundColor: "#F7F7F7" }}>
                                            <td>{count.newComplaints}</td>
                                            <td>{count.inProgrss} </td>
                                            <td>{count.completedComplaints} </td>
                                            <td>{count.closed} </td>
                                            <td>{count.reportedToHA} </td>
                                            <td>{count.autoEscalated} </td>
                                            <td>{count.totalCompaints} </td>
                                        </tr>
                                    )
                                }
                                )}
                            </tbody>
                        </table>
                    </div>
                    <div className={dastyles.tableFixHead}>
                        <table className={dastyles.tablecontainer}>
                            <thead>
                                <tr>
                                    <th className={dastyles.box1}>S.No</th>
                                    <th className={dastyles.box2}>Created On</th>
                                    <th className={dastyles.box3}>Grievance ID</th>
                                    <th className={dastyles.box4}>User Type </th>
                                    <th className={dastyles.box5}>Classification</th>
                                    <th className={dastyles.box5}>Subject</th>
                                    <th className={dastyles.box7}>Status</th>
                                    <th className={dastyles.box8}>Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    complaintList.data &&
                                    complaintList.data.map((complaint: any, index: any) => {
                                        return (
                                            <tr key={index} >
                                                <td width="4%" style={{ textAlign: "center", paddingLeft: "5px" }}>{srno = srno + 1}</td>
                                                {(LoginDetails.role == 'DIG' || LoginDetails.role == 'IG') && (Calculatedays(Moment((complaint.createdAt)).format("YYYY-MM-DD")) > 40) ?
                                                    <td width="12%" style={{ color: "red", textAlign: "center", paddingLeft: "5px" }}>{Moment((complaint.createdAt)).format("DD-MM-YYYY")}</td>
                                                    : <td width="12%" style={{ textAlign: "center", paddingLeft: "5px" }}>{Moment((complaint.createdAt)).format("DD-MM-YYYY")}</td>
                                                }

                                                <td width="16%" style={{ fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>{complaint.complaintNo}</td>
                                                <td width="16%" style={{ fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>{complaint.userType}</td>
                                                
                                                <td width="20%" style={{ textAlign: "center", paddingLeft: "5px" }}>{complaint.gravianceClassification && complaint.gravianceClassification} </td>
                                                <td width="20%" style={{ textAlign: "center", paddingLeft: "5px", wordBreak: 'break-word' }}>{complaint.gravianceClassification != "ANY OTHER" ? complaint.gravianceClassification : complaint.subject} </td>
                                                {complaint.complaintStatus == "Closed" ? <td style={{ color: "green", fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>{complaint.complaintStatus}</td> :
                                                    complaint.complaintStatus == "Appealed to Higher Authority" || complaint.complaintStatus == "In Progress" ? <td style={{ color: "#FF6C0A", fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>{complaint.complaintStatus}</td> :
                                                        complaint.complaintStatus == "Completed" ? <td style={{ color: "green", fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>{complaint.complaintStatus}</td> :
                                                            complaint.complaintStatus == "Completed" ? <td style={{ color: "green", fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>{complaint.complaintStatus}</td> :
                                                //                 complaint.complaintStatus == "Submitted" ?
                                                //                     <td style={{ color: "#33c5ce", fontWeight: "bold", textAlign: "left", paddingLeft: "5px" }}>New</td>
                                                //                     :
                                                //                     <td width="10%" style={{ fontWeight: "bold", textAlign: "left", paddingLeft: "5px" }}>{complaint.complaintStatus}</td>
                                                // }
                                                complaint.complaintStatus == "Submitted" ?
                                                                  <>
                                                                     {complaint.complaintStatus == "Submitted" && (Calculatedays(Moment((complaint.createdAt)).format("YYYY-MM-DD")) <= 5) ? <td style={{ color: "#33c5ce", fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>New</td> :
                                                                        <>{complaint.complaintStatus == "Submitted" && (Calculatedays(Moment((complaint.createdAt)).format("YYYY-MM-DD")) <= 10) && (Calculatedays(Moment((complaint.createdAt)).format("YYYY-MM-DD")) > 5) ? <td style={{ color: "#fca510", fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>New</td> :
                                                                            <td style={{ color: "red", fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>New</td>}
                                                                        </>}
                                                                        </>
                                                                    :
                                                                    <td width="10%" style={{ fontWeight: "bold", textAlign: "center", paddingLeft: "5px" }}>{complaint.complaintStatus}</td>
                                                }
                                                <td style={{ textAlign: "center", paddingLeft: "5px" }} width="4%" id={dastyles.logos}>
                                                    <div>
                                                        {LoginDetails.role == complaint.actionUnder && (complaint.complaintStatus !== "Completed") && !(complaint.complaintStatus == "Closed") ?
                                                            <div style={{ cursor: 'pointer' }} onClick={() => { onselectcomplaint(complaint.complaintNo, complaint.complaintStatus, complaint.loginType) }} >
                                                                <svg width="18" height="15" viewBox="0 0 22 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M15.9143 3.26621L18.3251 5.2587M17.4646 1.5109L10.9459 6.90107C10.6091 7.17919 10.3794 7.53353 10.2857 7.91943L9.68359 10.4117L12.6976 9.91287C13.1643 9.83569 13.5923 9.64651 13.9292 9.36792L20.4479 3.97775C20.6438 3.81577 20.7992 3.62348 20.9052 3.41185C21.0112 3.20022 21.0658 2.97339 21.0658 2.74432C21.0658 2.51526 21.0112 2.28843 20.9052 2.0768C20.7992 1.86517 20.6438 1.67288 20.4479 1.5109C20.252 1.34893 20.0195 1.22044 19.7635 1.13278C19.5076 1.04512 19.2333 1 18.9562 1C18.6792 1 18.4049 1.04512 18.149 1.13278C17.893 1.22044 17.6605 1.34893 17.4646 1.5109V1.5109Z" stroke="#333333" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                                    <path d="M18.7898 12.2938V15.1174C18.7898 15.6166 18.55 16.0954 18.1231 16.4484C17.6962 16.8014 17.1171 16.9997 16.5134 16.9997H3.99278C3.38902 16.9997 2.80999 16.8014 2.38307 16.4484C1.95615 16.0954 1.71631 15.6166 1.71631 15.1174V4.76433C1.71631 4.26509 1.95615 3.7863 2.38307 3.43329C2.80999 3.08028 3.38902 2.88196 3.99278 2.88196H7.40749" stroke="#333333" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div> :
                                                            <div style={{ cursor: 'pointer' }} onClick={() => { onselectcomplaint(complaint.complaintNo, "", complaint.loginType) }} >
                                                                <svg width="20" height="15" viewBox="0 0 29 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M28.4187 8.3021C27.3109 5.93269 25.3878 3.88362 22.887 2.40814C20.3861 0.932667 17.4173 0.0954609 14.3473 0C11.2773 0.0954609 8.30841 0.932667 5.80759 2.40814C3.30677 3.88362 1.38362 5.93269 0.275838 8.3021C0.201023 8.47321 0.201023 8.66058 0.275838 8.83169C1.38362 11.2011 3.30677 13.2502 5.80759 14.7256C8.30841 16.2011 11.2773 17.0383 14.3473 17.1338C17.4173 17.0383 20.3861 16.2011 22.887 14.7256C25.3878 13.2502 27.3109 11.2011 28.4187 8.83169C28.4935 8.66058 28.4935 8.47321 28.4187 8.3021ZM14.3473 15.5762C9.3554 15.5762 4.08096 12.5155 2.16898 8.5669C4.08096 4.61834 9.3554 1.55762 14.3473 1.55762C19.3391 1.55762 24.6136 4.61834 26.5256 8.5669C24.6136 12.5155 19.3391 15.5762 14.3473 15.5762Z" fill="#333333" />
                                                                    <path d="M14.347 3.89478C13.2293 3.89478 12.1367 4.16883 11.2074 4.68229C10.278 5.19575 9.5537 5.92555 9.12597 6.7794C8.69825 7.63326 8.58634 8.57281 8.80439 9.47926C9.02244 10.3857 9.56066 11.2183 10.351 11.8718C11.1413 12.5253 12.1483 12.9704 13.2445 13.1507C14.3407 13.331 15.477 13.2385 16.5096 12.8848C17.5422 12.5311 18.4248 11.9322 19.0458 11.1637C19.6667 10.3953 19.9982 9.49183 19.9982 8.56763C19.9982 7.32831 19.4028 6.13975 18.343 5.26342C17.2832 4.38709 15.8458 3.89478 14.347 3.89478ZM14.347 11.6829C13.6019 11.6829 12.8735 11.5002 12.2539 11.1579C11.6343 10.8155 11.1515 10.329 10.8663 9.75978C10.5812 9.19054 10.5066 8.56417 10.6519 7.95988C10.7973 7.35558 11.1561 6.8005 11.683 6.36482C12.2099 5.92915 12.8812 5.63245 13.612 5.51225C14.3428 5.39205 15.1003 5.45374 15.7887 5.68953C16.4771 5.92531 17.0655 6.3246 17.4795 6.8369C17.8935 7.34919 18.1144 7.95149 18.1144 8.56763C18.1144 9.39384 17.7175 10.1862 17.011 10.7704C16.3044 11.3547 15.3462 11.6829 14.347 11.6829Z" fill="#333333" />
                                                                </svg>
                                                            </div>
                                                        }
                                                    </div>
                                                </td>
                                            </tr>
                                        )
                                    }
                                    )}
                            </tbody>
                        </table>
                    </div>
                    <div className={dastyles.footer}>
                        <div>
                            {complaintList.data && complaintList.data.length} of {complaintList.data && complaintList.totalCount} items
                        </div>
                        <div className={dastyles.pagenumbers}>
                            {pagenumber < 6 ? null :
                                <div
                                    className={dastyles.pagenumber} onClick={() => pagehandler(1)}>
                                    1
                                </div>
                            }{pagenumber >= 6 ?
                                <div> . . .</div> : null}
                            {
                                pagenumbers.map((page, index) => {
                                    if ((parseInt(page)) > (5 + pagenumber) || (parseInt(page)) < (pagenumber - 5)) {
                                        return null;
                                    } else {
                                        return (
                                            <div
                                                style={{ backgroundColor: pagenumber == page ? "#394C90" : null, color: pagenumber == page ? "white" : "black" }}
                                                key={index} className={dastyles.pagenumber} onClick={() => pagehandler(page)}>
                                                {page}
                                            </div>
                                        )
                                    }
                                })
                            }
                            {pagenumber < (Math.ceil(complaintList.totalCount / 10) - 6) ?
                                <div> . . .</div> : null}
                            {pagenumber <= (Math.ceil(complaintList.totalCount / 10) - 6) ?
                                <div
                                    className={dastyles.pagenumber} onClick={() => pagehandler(Math.ceil(complaintList.totalCount / 10))}>
                                    {Math.ceil(complaintList.totalCount / 10)}
                                </div> : null}
                        </div>
                        <div>
                        </div>
                    </div>
                </div>
                {/* <pre>{JSON.stringify(pagenumber, null, 2)}</pre> */}
            </div>
        </>
    )
}
export default Dashboard
