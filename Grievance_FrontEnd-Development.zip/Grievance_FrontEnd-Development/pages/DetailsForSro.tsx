import styles from '../styles/pages/DetailsForSro.module.scss';
import { OfficerLogout, Updatestatus, usegetComplaintsByNo, useUploadDoc } from '../src/axios';
import Image from "next/image";
import Moment from 'moment';
import { useAppDispatch } from '../src/redux/hooks';
import { useRouter } from 'next/router';
import TableText from '../src/components/TableText';
import React, { useEffect, useState } from 'react';
import { LoadingAction, PopupAction } from '../src/redux/commonSlice';
import { useAppSelector } from '../src/redux/hooks';
import UploadDoc from '../src/components/UploadDoc';
import { Header } from '../src/components/Header';
import TableTextAera from '../src/components/TableTextAera';
import dastyles from '../styles/pages/Dashboard.module.scss'
const DetailsForSro = () => {
    const dispatch = useAppDispatch()
    const router = useRouter()
    let initialLoginDetails = useAppSelector((state) => state.login.loginDetails);
    const [LoginDetails, setLoginDetails] = useState(initialLoginDetails);
    const [ComplaintStatus, setComplaintStatus] = useState<any>({});
    const [isfinalSubmit, setisfinalSubmit] = useState<Boolean>(false)
    const [TempUploadDetails, setTempUploadDetails] = useState<any>([]);
    const ShowAlert = (type, message, redirectLocation) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirectLocation })); }
    const Loading = (value: boolean) => { dispatch(LoadingAction({ enable: value })); }
    const onChange = (e: any) => {
        let addName = e.target.name
        let addValue = e.target.value;
        if (addName == "comment") {
            if (addValue == " ") { addValue = ""; }
            if (addValue.length > 1000) {
                addValue = addValue.substring(0, 1000);
            }
        }
        setComplaintStatus({ ...ComplaintStatus, [addName]: addValue })
    }
    const OnFileSelect = async (event: any, docName: string, uploadName: string) => {
        if (event.target.files.length) {
            if (event.target.files[0].size > 5245329) {
                ShowAlert(false, "File size should not be more than 5MB.", "");
                event.target.value = "";
            }
            else {
                const file = event.target.files[0];
                console.log(file)
                let fileNamesSplit = file.name.split('.');
                let validFileExtensions = ["jpg", "jpeg", "bmp", "png", "pdf"];
                if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
                    // throw Error("Invalid File");
                    ShowAlert(false, "Irrelevant file type. Only image/pdf can be uploaded.", "");
                    event.target.value = "";
                }
                else {
                    setComplaintStatus({ ...ComplaintStatus, [uploadName]: "process" });
                    const formData = new FormData();
                    formData.append('image', event.target.files[0]);
                    let data: any = {
                        docName: docName,
                    }
                    await ForUploadDoc(data, formData, uploadName, "");
                }
            }
        }
    }
    const ForUploadDoc = async (data: any, formData: any, uploadName: string, loginType: any) => {
        Loading(true)
        let result = await useUploadDoc(data, formData);
        Loading(false);
        if (result.status) {
            let documents = [];
            documents.push(result.data);
            setTempUploadDetails(documents);
            setComplaintStatus({ ...ComplaintStatus, [uploadName]: "true" });
        }
        else {
            setComplaintStatus({ ...ComplaintStatus, [uploadName]: "false" });
        }
    }

    const fetchFile = (url) => {
        fetch(url).then(res => res.blob()).then(file => {
            let tempUrl = URL.createObjectURL(file);
            const aTag = document.createElement("a");
            aTag.href = tempUrl;
            aTag.download = url.replace(/^.*[\\\/]/, '');
            document.body.appendChild(aTag);
            aTag.click();
            URL.revokeObjectURL(tempUrl);
            aTag.remove();
        }).catch(() => {
            alert("Failed to download file!");
        });
    }
    const updatestatusinfo = async () => {
        let data = {
            complaintStatus: LoginDetails.role == "IG" ? "Closed" : "Completed",
            complaintNo: ComplaintStatus.complaintNo,
            isReportedToHA: LoginDetails.role == "IG" ? true : false,
            commentsList: [{
                comment: ComplaintStatus.comment,
                name: (LoginDetails.loginName == null ? "USER" : LoginDetails.loginName),
                role: (LoginDetails.role == "DR" || LoginDetails.role == "DIG" || LoginDetails.role == "IG" ? LoginDetails.role : "USER"),
                uploadFile: { documents: TempUploadDetails }
            }]
        };
        Loading(true);
        let result = await Updatestatus(data);
        Loading(false);
        if (result.status) {
            ShowAlert(true, 'Completed Successfully', "");
            await getComplaintsByNo(ComplaintStatus.complaintNo);
        } else {
            ShowAlert(false, 'Update failed', "");
        }
    }
    useEffect(() => {
        let data: any = localStorage.getItem("loginDetails");
        data = JSON.parse(data);
        if (data && data.token) {
            setLoginDetails(data)
        }
        else {
            router.push("/Login");
        }
    }, [])
    useEffect(() => {
        getComplaintsByNo(localStorage.getItem("complaintNo"))
    }, [LoginDetails])
    const getComplaintsByNo = async (complaintNo: any) => {
        if (LoginDetails.role == "DR" || LoginDetails.role == "IG" || LoginDetails.role == "DIG") {
            Loading(true);
            let result = await usegetComplaintsByNo(complaintNo);
            Loading(false);
            if (result.status) {
                setComplaintStatus(result.data[0]);
            } else {
                ShowAlert(false, result.message, "")
            }
        }
    }
    const OnSubmitUpdate = async (e: any) => {
        e.preventDefault();
        await updatestatusinfo()
    };

    const onCancelUpload = (uploadKey) => {
        setComplaintStatus({ ...ComplaintStatus, [uploadKey]: "", documents: [] });
    }
    const openNewTab = (Link) => { window.open(Link) }
    const current = new Date();
    const date = `${current.getDate()}/${current.getMonth() + 1}/${current.getFullYear()}`;
    const Calculatedays = (complaintdate: any) => {
        const date1: any = new Date(complaintdate);
        const current: any = new Date();
        const date = `${current.getFullYear()}-${current.getMonth() + 1}-${current.getDate()}`;
        const currentdate: any = new Date(date);
        const diffTime = Math.abs(currentdate - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    }
    const DisplayTable = (key: any, value: any, color) => {
        return (
            <div className={styles.DisplayTableContainer} style={{ display: 'flex', backgroundColor: color, marginBottom: '2px' }}>
                <div className={styles.KeyContainer} >
                    <text className={styles.keyText}>{key}</text>
                </div>:
                <div className={styles.ValueContainer}>
                    {key == "Description" ?
                        <TableTextAera value={value} />
                        :
                        <text style={{ color: key == "Status" ? StatusColor(value) : null, fontWeight: key == "Status" ? "bold" : null }} className={styles.valueText}>{value}</text>
                    }
                </div>
            </div>
        );
    }
    const StatusColor = (mystatus: any) => {
        switch (mystatus) {
            case "Appealed to Higher Authority": return "#FF5C00";
            case "Closed": return "#2B8E46";
            case "Submitted": return "#394C90";
            default: return "#333333";
        }
    }
    const redirectToPage = (location: string, query: {}) => {
        router.push({
            pathname: location,
        })
    }
    const DisplayTable2 = (key1, value1, key2, value2, color) => {
        return (
            <div className={styles.detailsInfo} style={{ marginBottom: '2px' }}>
                <div className={styles.detailsCol}>
                    <div className={styles.DisplayTableContainer} style={{ display: 'flex', backgroundColor: color}}>
                        <div className={styles.KeyContainer} style={{ width: '50%' }} >
                            <text className={styles.keyText}>{key1}</text>
                        </div>:
                        <div className={styles.ValueContainer}>
                            <text className={styles.valueText}>{value1}</text>
                        </div>
                    </div>
                </div>
                <div className={styles.detailsCol}>
                    <div className={styles.DisplayTableContainer} style={{ display: 'flex', backgroundColor: color }}>
                        <div className={styles.rightKeyContainer} style={{ width: '50%' }} >
                            <text className={styles.keyText}>{key2}</text>
                        </div>:
                        <div className={styles.ValueContainer}>
                            <text className={styles.valueText}>{value2}</text>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    const DisplayRedressal = (key: any, value: any, color) => {
        return (
            <div className={styles.DisplayTableContainer1} style={{ backgroundColor: key == "Appeal from the Complainant" ? "#F4F4F4" : color, marginBottom: '2px' }}>
                <div className={styles.KeyContainer1} style={{ backgroundColor: key == "Appeal from the Complainant" ? "#F4F4F4" : null }} >
                    <text className={styles.keyText1} style={{ color: 'black' }}>{key}</text>
                </div>
                <div className={styles.ValueContainer1}>
                    <text style={{ color: key == "Status" ? StatusColor(value) : null, fontWeight: key == "Status" ? "bold" : null }} className={styles.valueText1}>{value}</text>
                </div>
            </div>
        );
    }
    const onLogout = () => {
        OfficerLogout();
        setTimeout(() => { localStorage.clear(); }, 200);
        setTimeout(() => {
            router.push("/Login");
        }, 0)
        // localStorage.removeItem('LoginUser');
    }
    return (
        <div>
            <Header />
            <div className='MainContent'>
                <div className={dastyles.Navbar}><text className={dastyles.NavbarText}> Welcome: {LoginDetails.loginName}({LoginDetails && LoginDetails.role.toUpperCase()}) {LoginDetails.role == 'DR' ? <text>{LoginDetails.district}</text> : null} [<text className={dastyles.NavbarText}> Last Login : {LoginDetails.lastLogin}</text>]
                </text>
                    <div style={{ display: "flex", paddingTop: "2px" }}>
                        <button style={{ cursor: 'pointer' }} className={dastyles.navbarbutton} onClick={onLogout} > Logout</button>
                    </div>
                    </div>
                <div className={styles.Container}>
                    <div className={styles.subcontainer} style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ display: "flex" }}> <Image style={{ marginRight: "5px", cursor: "pointer" }} alt='' width={14} height={14} className={styles.image} onClick={() => { redirectToPage("/Dashboard", {}) }} src="/grievance/images/backbutton.svg"></Image> <text className={styles.TitleText}>Details of Lodged Grievance</text></div>
                    </div>
                    <div className={styles.subcontainer}>
                        <div className={styles.title1}>
                            <text className={styles.TitleText1}>{ComplaintStatus && ComplaintStatus.complaintNo} Details</text>
                        </div>
                        {DisplayTable2("Grievance Date", ComplaintStatus && ComplaintStatus.createdAt ? Moment((ComplaintStatus && ComplaintStatus.createdAt)).format("DD-MM-YYYY") : "", "Classification", ComplaintStatus && ComplaintStatus.gravianceClassification, "#F4F4F4")}
                        {DisplayTable2("Person Name", ComplaintStatus && ComplaintStatus.personName, "Mobile Number", ComplaintStatus && ComplaintStatus.phoneNumber, "#F4F4F4")}
                        {DisplayTable2("Email ID", ComplaintStatus && ComplaintStatus.email, "District", ComplaintStatus && ComplaintStatus.district, "#F4F4F4")}
                        {DisplayTable2("Mandal", ComplaintStatus && ComplaintStatus.mandal, "SRO", ComplaintStatus && ComplaintStatus.sro, "#F4F4F4")}
                        {ComplaintStatus && ComplaintStatus.subject ? DisplayTable("Subject", ComplaintStatus && ComplaintStatus.subject, "#F4F4F4") : DisplayTable("Subject", ComplaintStatus && ComplaintStatus.gravianceClassification, "#F4F4F4")}
                        {DisplayTable("Description", ComplaintStatus && ComplaintStatus.description, "#F4F4F4")}
                        {DisplayTable("User Type", ComplaintStatus && ComplaintStatus.userType, "#F4F4F4")}
                        {ComplaintStatus && ComplaintStatus.documents && ComplaintStatus.documents.length ? DisplayTable("Document",
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <div style={{ cursor: 'pointer' }} >
                                    <text className={styles.valueText} style={{ fontWeight: "700", cursor: 'pointer', color: 'black' }}>{ComplaintStatus && ComplaintStatus.documents[0].fileName}</text>
                                </div>
                                <div style={{ display: 'flex' }}>
                                    <div style={{ cursor: 'pointer', marginRight: '1rem', display: 'flex' }} onClick={async () => { (await window.open(ComplaintStatus.documents[0].downloadLink)) }}>
                                        <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700", color: 'black' }}>View</text>
                                        <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px', marginRight: '10px' }} src="/grievance/images/eye.svg"></Image>
                                    </div>
                                    <div style={{ cursor: 'pointer', display: 'flex' }} onClick={() => fetchFile(ComplaintStatus.documents[0].downloadLink)}  >
                                        <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700", color: 'black' }}>Download</text>
                                        <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/download.svg"></Image>
                                    </div>
                                </div>
                            </div>
                            , "#F4F4F4") : null}
                        {ComplaintStatus && ComplaintStatus.commentsList && <div>
                            {ComplaintStatus && ComplaintStatus.commentsList.map((comment: any, index: any) => {
                                return (
                                    <div key={index}>
                                        {(comment.role == "DR" || comment.role == "DIG" || comment.role == "IG")
                                            ?
                                            <div style={{ marginTop: '2rem' }}>
                                                <div className={styles.title} >
                                                    <text className={styles.TitleText}>Redressal by {comment.role == "DR" ? "District Registrar" : "Higher Authority (" + comment.role + ")"}</text>
                                                </div>
                                                {DisplayRedressal("Comments",
                                                    <TableTextAera value={comment.comment} />
                                                    , "#FFFFFF")}
                                                {comment.uploadFile.documents.length ? DisplayRedressal("Document by Officer",
                                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                                        <div style={{ cursor: 'pointer' }} >
                                                            <text className={styles.valueText} style={{ marginRight: '50px', fontWeight: "700", cursor: 'pointer' }}>{comment.uploadFile.documents[0].fileName}</text>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', marginRight: '1rem', display: 'flex' }} onClick={async () => { (await window.open(comment.uploadFile.documents[0].downloadLink)) }}>
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>View</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/eye.svg"></Image>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', display: 'flex' }} onClick={() => fetchFile(comment.uploadFile.documents[0].downloadLink)}  >
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>Download</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/download.svg"></Image>
                                                        </div>
                                                    </div>
                                                    , "#FFFFFF") : null}
                                            </div>
                                            :
                                            <div style={{ marginTop: '5rem', backgroundColor: '#F4F4F4', padding: '10px', width: '100%' }}>
                                                {DisplayRedressal("Appeal from the Complainant",
                                                    <TableTextAera value={comment.comment} />
                                                    , "#FFFFFF")}
                                                {comment.uploadFile.documents.length ? DisplayRedressal("Document by Officer",
                                                    <div style={{ display: 'flex', paddingTop: '5px', alignItems: 'center' }}>
                                                        <div style={{ cursor: 'pointer' }} >
                                                            <text className={styles.valueText} style={{ marginRight: '50px', fontWeight: "700", cursor: 'pointer' }}>{comment.uploadFile.documents[0].fileName}</text>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', marginRight: '1rem', display: 'flex' }} onClick={async () => { (await window.open(comment.uploadFile.documents[0].downloadLink)) }}>
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>View</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/eye.svg"></Image>
                                                        </div>
                                                        <div style={{ cursor: 'pointer', display: 'flex' }} onClick={() => fetchFile(comment.uploadFile.documents[0].downloadLink)}  >
                                                            <text className={styles.valueText} style={{ marginRight: '5px', fontWeight: "700" }}>Download</text>
                                                            <Image alt='' width={20} height={20} className={styles.image} style={{ marginLeft: '2px' }} src="/grievance/images/download.svg"></Image>
                                                        </div>
                                                    </div>
                                                    , "#F4F4F4") : null}
                                            </div>
                                        }
                                    </div>
                                )
                            })}</div>
                        }
                    </div>
                    <form onSubmit={OnSubmitUpdate}>
                        {LoginDetails.role == ComplaintStatus.actionUnder && (ComplaintStatus && ComplaintStatus.complaintStatus !== "Completed" && !(ComplaintStatus.complaintStatus == "Closed")) ?

                            <div className={styles.hiddencontainer}>
                                <div><text className={styles.TitleText}>For Officer&#39;s Use</text> </div>
                                <div className={styles.Textarea}>
                                    <TableText label="Comments" required={true} LeftSpace={false} />
                                    <textarea className={styles.textarea} rows={3} name='comment'
                                        style={{ width: '88%', borderColor: '#AEAEAE', borderRadius: '3px' }}
                                        placeholder={'Enter Max 1000 Characters'}
                                        required={true}
                                        value={ComplaintStatus.comment}
                                        onChange={onChange} />
                                </div>
                                <text  style={{ color: 'red',fontSize:'12px' }} >*Note : Please upload only in JPG/JPEG/PNG/PDF format and maximum size 5 MB only.</text>
                                <div className={styles.uploaddocuments}>
                                    <TableText label="Upload Documents" required={false} LeftSpace={false} />
                                    <UploadDoc isUploadDone={ComplaintStatus.sroUploadDocuments} label="" required={false} uploadKey={"sroUploadDocuments"} onCancelUpload={onCancelUpload} onChange={(e: any) => { OnFileSelect(e, "documents", "sroUploadDocuments"); }} />
                                </div>
                                <div>
                                    <button className={styles.submitButtonsro}>Submit</button>
                                </div>
                            </div> : null}
                    </form>
                </div>
            </div>
        </div>
    )
}

export default DetailsForSro