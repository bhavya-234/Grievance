import type { NextPage } from 'next';
import Head from 'next/head';
import styles from '../styles/Home.module.scss';
import Mainpage from './Mainpage';
const Home: NextPage = () => { 
  return (
    <div className={styles.container}>
      <Head>
        <title>Grievance Page</title>
        <link rel="icon" href="/grievance/images/icon-apGov.jpg" />
      </Head>
      <Mainpage/>
    </div>
  )
}

export default Home
