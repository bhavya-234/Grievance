import React, { useEffect, useLayoutEffect } from 'react'
import { useRouter } from 'next/router';
import styles from '../styles/pages/Mainpage.module.scss'
import Image from "next/image";
import MyNavbar from '../src/components/MyNavbar';
import { Header } from '../src/components/Header';

const Mainpage = () => {
  const router = useRouter();
  useLayoutEffect(() => {
    localStorage.clear();
  }, []);
  const redirectToPage = (location: string, query: {}) => {
      router.push({
        pathname: location,
        query:query
      })
  }
  return (
    <div>
      <Header />
      <div className='MainContent'>
        <MyNavbar />
        <div style={{textAlign:"center",paddingTop:"15%"}}>
        <button className={styles.button1} onClick={() => { redirectToPage("/ComplaintLodging",{portal:"E-CHITS"}&&{}) }}>Lodge Grievance</button>
        </div>
      </div>
    </div>
  )
}

export default Mainpage
